-- Conecta+ — schema aditivo e reexecutável para o Supabase.
-- Não remove tabelas, linhas, índices, funções, gatilhos ou políticas.
-- Execute no SQL Editor. O script usa uma transação: incompatibilidades
-- interrompem a execução sem deixar metade da configuração aplicada.

begin;

-- Esquema privado exclusivo do Conecta+; não altera o schema private genérico.
create schema if not exists conecta_plus_private;
revoke all on schema conecta_plus_private from public, anon;
grant usage on schema conecta_plus_private to authenticated;

-- Reutiliza uma chave única já existente; cria um índice somente se necessário.
create or replace function conecta_plus_private.conecta_plus_ensure_unique_index(
  p_table regclass,
  p_index_name text,
  p_columns text[]
)
returns void
language plpgsql
set search_path = ''
as $$
declare
  v_column_sql text;
  v_namespace oid;
begin
  if p_table is null or coalesce(array_length(p_columns, 1), 0) = 0 then
    raise exception 'Tabela ou colunas inválidas ao preparar índice único.';
  end if;

  if exists (
    select 1
    from pg_catalog.pg_index as index_info
    where index_info.indrelid = p_table
      and index_info.indisunique
      and index_info.indisvalid
      and index_info.indisready
      and index_info.indpred is null
      and index_info.indexprs is null
      and index_info.indnkeyatts = array_length(p_columns, 1)
      and array(
        select attribute.attname::text
        from pg_catalog.unnest(index_info.indkey::smallint[])
          with ordinality as index_column(attnum, ordinality)
        join pg_catalog.pg_attribute as attribute
          on attribute.attrelid = index_info.indrelid
         and attribute.attnum = index_column.attnum
        where index_column.ordinality <= index_info.indnkeyatts
        order by index_column.ordinality
      ) = p_columns
  ) then
    return;
  end if;

  select relation.relnamespace
  into v_namespace
  from pg_catalog.pg_class as relation
  where relation.oid = p_table;

  if exists (
    select 1
    from pg_catalog.pg_class as relation
    where relation.relnamespace = v_namespace
      and relation.relname = p_index_name
  ) then
    raise exception
      'O índice "%" já existe com outra definição; revise-o manualmente antes de continuar.',
      p_index_name;
  end if;

  select string_agg(
    pg_catalog.format('%I', column_name),
    ', ' order by ordinal_position
  )
  into v_column_sql
  from pg_catalog.unnest(p_columns)
    with ordinality as requested_column(column_name, ordinal_position);

  execute pg_catalog.format(
    'create unique index %I on %s (%s)',
    p_index_name,
    p_table,
    v_column_sql
  );
end;
$$;

-- Adiciona uma FK ausente sem validar nem alterar dados antigos.
-- Se houver uma FK incompatível na mesma coluna, interrompe sem removê-la.
create or replace function conecta_plus_private.conecta_plus_ensure_foreign_key(
  p_source_table regclass,
  p_source_column text,
  p_target_table regclass,
  p_target_column text,
  p_constraint_name text
)
returns void
language plpgsql
set search_path = ''
as $$
declare
  v_source_attnum smallint;
  v_target_attnum smallint;
  v_existing record;
  v_matching_fk boolean := false;
begin
  select attribute.attnum
  into v_source_attnum
  from pg_catalog.pg_attribute as attribute
  where attribute.attrelid = p_source_table
    and attribute.attname = p_source_column
    and not attribute.attisdropped;

  select attribute.attnum
  into v_target_attnum
  from pg_catalog.pg_attribute as attribute
  where attribute.attrelid = p_target_table
    and attribute.attname = p_target_column
    and not attribute.attisdropped;

  if v_source_attnum is null or v_target_attnum is null then
    raise exception 'Não foi possível localizar as colunas necessárias para a chave estrangeira.';
  end if;

  for v_existing in
    select constraint_info.conname,
           constraint_info.confrelid,
           constraint_info.confkey
    from pg_catalog.pg_constraint as constraint_info
    where constraint_info.conrelid = p_source_table
      and constraint_info.contype = 'f'
      and constraint_info.conkey = array[v_source_attnum]::smallint[]
  loop
    if v_existing.confrelid = p_target_table
       and v_existing.confkey = array[v_target_attnum]::smallint[] then
      v_matching_fk := true;
    else
      raise exception
        'A tabela % já tem uma FK incompatível na coluna %. Nenhuma FK foi removida; revise a estrutura antes de continuar.',
        p_source_table,
        p_source_column;
    end if;
  end loop;

  if v_matching_fk then
    return;
  end if;

  execute pg_catalog.format(
    'alter table %s add constraint %I foreign key (%I) references %s (%I) on delete restrict not valid',
    p_source_table,
    p_constraint_name,
    p_source_column,
    p_target_table,
    p_target_column
  );
end;
$$;

-- CHECK NOT VALID preserva linhas existentes e protege novas gravações.
create or replace function conecta_plus_private.conecta_plus_ensure_check(
  p_table regclass,
  p_constraint_name text,
  p_expression text
)
returns void
language plpgsql
set search_path = ''
as $$
begin
  if exists (
    select 1
    from pg_catalog.pg_constraint as constraint_info
    where constraint_info.conrelid = p_table
      and constraint_info.conname = p_constraint_name
  ) then
    return;
  end if;

  execute pg_catalog.format(
    'alter table %s add constraint %I check (%s) not valid',
    p_table,
    p_constraint_name,
    p_expression
  );
end;
$$;

-- Cria ou atualiza apenas as políticas Conecta+ com o mesmo nome.
-- Nunca apaga políticas existentes; políticas restritivas separadas abaixo
-- limitam políticas permissivas antigas que possam ser mais amplas.
create or replace function conecta_plus_private.conecta_plus_ensure_policy(
  p_schema text,
  p_table text,
  p_policy_name text,
  p_command text,
  p_mode text,
  p_using text,
  p_check text
)
returns void
language plpgsql
set search_path = ''
as $$
declare
  v_existing_mode text;
  v_existing_command text;
  v_using_clause text := '';
  v_check_clause text := '';
  v_table_identifier text;
begin
  if upper(p_command) not in ('SELECT', 'INSERT', 'UPDATE', 'DELETE', 'ALL')
     or upper(p_mode) not in ('PERMISSIVE', 'RESTRICTIVE') then
    raise exception 'Comando ou modo de política inválido.';
  end if;

  v_table_identifier := pg_catalog.format('%I.%I', p_schema, p_table);

  select policy.permissive, policy.cmd
  into v_existing_mode, v_existing_command
  from pg_catalog.pg_policies as policy
  where policy.schemaname = p_schema
    and policy.tablename = p_table
    and policy.policyname = p_policy_name;

  if found then
    if v_existing_command <> upper(p_command)
       or v_existing_mode <> upper(p_mode) then
      raise exception
        'A política "%" já existe com comando ou modo incompatível. Ela não foi removida nem convertida.',
        p_policy_name;
    end if;
  end if;

  if p_using is not null then
    v_using_clause := pg_catalog.format(' using (%s)', p_using);
  end if;
  if p_check is not null then
    v_check_clause := pg_catalog.format(' with check (%s)', p_check);
  end if;

  if found then
    execute pg_catalog.format(
      'alter policy %I on %s to authenticated%s%s',
      p_policy_name,
      v_table_identifier,
      v_using_clause,
      v_check_clause
    );
  else
    execute pg_catalog.format(
      'create policy %I on %s as %s for %s to authenticated%s%s',
      p_policy_name,
      v_table_identifier,
      upper(p_mode),
      upper(p_command),
      v_using_clause,
      v_check_clause
    );
  end if;
end;
$$;

-- Cria o gatilho se estiver ausente; não substitui gatilho incompatível.
create or replace function conecta_plus_private.conecta_plus_ensure_trigger(
  p_schema text,
  p_table text,
  p_trigger_name text,
  p_trigger_clause text,
  p_function regprocedure,
  p_expected_type integer
)
returns void
language plpgsql
set search_path = ''
as $$
declare
  v_table regclass;
  v_trigger record;
begin
  v_table := pg_catalog.to_regclass(
    pg_catalog.format('%I.%I', p_schema, p_table)
  );

  select trigger_info.tgfoid,
         trigger_info.tgtype,
         trigger_info.tgenabled,
         trigger_info.tgqual,
         trigger_info.tgnargs
  into v_trigger
  from pg_catalog.pg_trigger as trigger_info
  where trigger_info.tgrelid = v_table
    and trigger_info.tgname = p_trigger_name
    and not trigger_info.tgisinternal;

  if not found then
    execute pg_catalog.format(
      'create trigger %I %s on %s for each row execute function %s',
      p_trigger_name,
      p_trigger_clause,
      v_table,
      p_function
    );
    return;
  end if;

  if v_trigger.tgfoid <> p_function::oid
     or v_trigger.tgtype <> p_expected_type
     or v_trigger.tgqual is not null
     or v_trigger.tgnargs <> 0 then
    raise exception
      'O gatilho "%" já existe com comportamento diferente. Ele não foi removido nem substituído.',
      p_trigger_name;
  end if;

  if v_trigger.tgenabled = 'D' then
    execute pg_catalog.format(
      'alter table %s enable trigger %I',
      v_table,
      p_trigger_name
    );
  end if;
end;
$$;

create table if not exists public.profiles (
  id uuid primary key,
  display_name text not null
    constraint conecta_plus_profiles_display_name_check
    check (char_length(display_name) between 2 and 80),
  username text not null
    constraint conecta_plus_profiles_username_check
    check (username ~ '^[a-z0-9_]{3,24}$'),
  bio text
    constraint conecta_plus_profiles_bio_check
    check (bio is null or char_length(bio) <= 300),
  city text
    constraint conecta_plus_profiles_city_check
    check (city is null or char_length(city) <= 100),
  avatar_url text
    constraint conecta_plus_profiles_avatar_url_check
    check (avatar_url is null or char_length(avatar_url) <= 500),
  is_discoverable boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null,
  recipient_id uuid not null,
  status text not null default 'pending'
    constraint conecta_plus_friend_requests_status_check
    check (status in ('pending', 'accepted', 'declined')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint conecta_plus_friend_requests_not_self_check
    check (sender_id <> recipient_id)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null,
  user_id uuid not null,
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null,
  sender_id uuid not null,
  body text not null
    constraint conecta_plus_messages_body_check
    check (char_length(trim(body)) between 1 and 3000),
  created_at timestamptz not null default now()
);

-- CREATE TABLE IF NOT EXISTS não altera uma tabela preexistente.
-- Confirma a compatibilidade antes de aplicar políticas ou funções.
do $$
declare
  v_incompatible_columns text;
begin
  select string_agg(
    expected.table_name || '.' || expected.column_name
      || ' (esperado: ' || expected.expected_type || ')',
    ', ' order by expected.table_name, expected.column_name
  )
  into v_incompatible_columns
  from (
    values
      ('profiles', 'id', 'uuid'),
      ('profiles', 'display_name', 'text'),
      ('profiles', 'username', 'text'),
      ('profiles', 'bio', 'text'),
      ('profiles', 'city', 'text'),
      ('profiles', 'avatar_url', 'text'),
      ('profiles', 'is_discoverable', 'boolean'),
      ('profiles', 'created_at', 'timestamp with time zone'),
      ('profiles', 'updated_at', 'timestamp with time zone'),
      ('friend_requests', 'id', 'uuid'),
      ('friend_requests', 'sender_id', 'uuid'),
      ('friend_requests', 'recipient_id', 'uuid'),
      ('friend_requests', 'status', 'text'),
      ('friend_requests', 'created_at', 'timestamp with time zone'),
      ('friend_requests', 'updated_at', 'timestamp with time zone'),
      ('conversations', 'id', 'uuid'),
      ('conversations', 'created_at', 'timestamp with time zone'),
      ('conversation_members', 'conversation_id', 'uuid'),
      ('conversation_members', 'user_id', 'uuid'),
      ('conversation_members', 'joined_at', 'timestamp with time zone'),
      ('messages', 'id', 'uuid'),
      ('messages', 'conversation_id', 'uuid'),
      ('messages', 'sender_id', 'uuid'),
      ('messages', 'body', 'text'),
      ('messages', 'created_at', 'timestamp with time zone')
  ) as expected(table_name, column_name, expected_type)
  left join pg_catalog.pg_class as relation
    on relation.relname = expected.table_name
   and relation.relnamespace = 'public'::regnamespace
  left join pg_catalog.pg_attribute as attribute
    on attribute.attrelid = relation.oid
   and attribute.attname = expected.column_name
   and not attribute.attisdropped
  where relation.oid is null
     or relation.relkind not in ('r', 'p')
     or attribute.attnum is null
     or pg_catalog.format_type(attribute.atttypid, attribute.atttypmod)
          <> expected.expected_type;

  if v_incompatible_columns is not null then
    raise exception
      'Há tabelas ou colunas existentes incompatíveis: %.',
      v_incompatible_columns
      using hint =
        'O script não remove nem converte estruturas existentes. Revise as colunas antes de executá-lo novamente.';
  end if;

  if exists (
    select 1 from public.profiles
    where id is null or display_name is null or username is null
       or is_discoverable is null or created_at is null or updated_at is null
  ) or exists (
    select 1 from public.friend_requests
    where id is null or sender_id is null or recipient_id is null
       or status is null or created_at is null or updated_at is null
  ) or exists (
    select 1 from public.conversations
    where id is null or created_at is null
  ) or exists (
    select 1 from public.conversation_members
    where conversation_id is null or user_id is null or joined_at is null
  ) or exists (
    select 1 from public.messages
    where id is null or conversation_id is null or sender_id is null
       or body is null or created_at is null
  ) then
    raise exception
      'Há linhas existentes sem valores obrigatórios. Nenhuma linha foi alterada.';
  end if;
end;
$$;

-- Defaults/not-null são aditivos; nenhum valor existente é reescrito.
alter table public.profiles
  alter column id set not null,
  alter column display_name set not null,
  alter column username set not null,
  alter column is_discoverable set default true,
  alter column is_discoverable set not null,
  alter column created_at set default now(),
  alter column created_at set not null,
  alter column updated_at set default now(),
  alter column updated_at set not null;

alter table public.friend_requests
  alter column id set default gen_random_uuid(),
  alter column id set not null,
  alter column sender_id set not null,
  alter column recipient_id set not null,
  alter column status set default 'pending',
  alter column status set not null,
  alter column created_at set default now(),
  alter column created_at set not null,
  alter column updated_at set default now(),
  alter column updated_at set not null;

alter table public.conversations
  alter column id set default gen_random_uuid(),
  alter column id set not null,
  alter column created_at set default now(),
  alter column created_at set not null;

alter table public.conversation_members
  alter column conversation_id set not null,
  alter column user_id set not null,
  alter column joined_at set default now(),
  alter column joined_at set not null;

alter table public.messages
  alter column id set default gen_random_uuid(),
  alter column id set not null,
  alter column conversation_id set not null,
  alter column sender_id set not null,
  alter column body set not null,
  alter column created_at set default now(),
  alter column created_at set not null;

-- Reutiliza PKs/índices únicos existentes ou cria índices equivalentes.
select conecta_plus_private.conecta_plus_ensure_unique_index(
  'public.profiles'::regclass, 'conecta_plus_profiles_id_uq', array['id']
);
select conecta_plus_private.conecta_plus_ensure_unique_index(
  'public.friend_requests'::regclass, 'conecta_plus_friend_requests_id_uq', array['id']
);
select conecta_plus_private.conecta_plus_ensure_unique_index(
  'public.conversations'::regclass, 'conecta_plus_conversations_id_uq', array['id']
);
select conecta_plus_private.conecta_plus_ensure_unique_index(
  'public.conversation_members'::regclass,
  'conecta_plus_conversation_members_pair_uq',
  array['conversation_id', 'user_id']
);
select conecta_plus_private.conecta_plus_ensure_unique_index(
  'public.messages'::regclass, 'conecta_plus_messages_id_uq', array['id']
);

create unique index if not exists profiles_username_lower_unique
  on public.profiles (lower(username));
create unique index if not exists friend_requests_one_active_pair
  on public.friend_requests (
    least(sender_id, recipient_id),
    greatest(sender_id, recipient_id)
  )
  where status in ('pending', 'accepted');
create index if not exists friend_requests_recipient_status
  on public.friend_requests (recipient_id, status, created_at desc);
create index if not exists friend_requests_sender_status
  on public.friend_requests (sender_id, status, created_at desc);
create index if not exists conversation_members_user_id
  on public.conversation_members (user_id, conversation_id);
create index if not exists messages_conversation_created
  on public.messages (conversation_id, created_at desc);

-- CHECK constraints ausentes são adicionadas como NOT VALID para preservar
-- valores antigos; novas gravações continuam sujeitas às validações.
select conecta_plus_private.conecta_plus_ensure_check(
  'public.profiles'::regclass,
  'conecta_plus_profiles_display_name_check',
  'char_length(display_name) between 2 and 80'
);
select conecta_plus_private.conecta_plus_ensure_check(
  'public.profiles'::regclass,
  'conecta_plus_profiles_username_check',
  'username ~ ''^[a-z0-9_]{3,24}$'''
);
select conecta_plus_private.conecta_plus_ensure_check(
  'public.profiles'::regclass,
  'conecta_plus_profiles_bio_check',
  'bio is null or char_length(bio) <= 300'
);
select conecta_plus_private.conecta_plus_ensure_check(
  'public.profiles'::regclass,
  'conecta_plus_profiles_city_check',
  'city is null or char_length(city) <= 100'
);
select conecta_plus_private.conecta_plus_ensure_check(
  'public.profiles'::regclass,
  'conecta_plus_profiles_avatar_url_check',
  'avatar_url is null or char_length(avatar_url) <= 500'
);
select conecta_plus_private.conecta_plus_ensure_check(
  'public.friend_requests'::regclass,
  'conecta_plus_friend_requests_status_check',
  'status in (''pending'', ''accepted'', ''declined'')'
);
select conecta_plus_private.conecta_plus_ensure_check(
  'public.friend_requests'::regclass,
  'conecta_plus_friend_requests_not_self_check',
  'sender_id <> recipient_id'
);
select conecta_plus_private.conecta_plus_ensure_check(
  'public.messages'::regclass,
  'conecta_plus_messages_body_check',
  'char_length(trim(body)) between 1 and 3000'
);

-- FKs ausentes são adicionadas NOT VALID: os dados antigos não são reescritos.
select conecta_plus_private.conecta_plus_ensure_foreign_key(
  'public.profiles'::regclass, 'id',
  'auth.users'::regclass, 'id',
  'conecta_plus_profiles_auth_user_fk'
);
select conecta_plus_private.conecta_plus_ensure_foreign_key(
  'public.friend_requests'::regclass, 'sender_id',
  'public.profiles'::regclass, 'id',
  'conecta_plus_friend_requests_sender_fk'
);
select conecta_plus_private.conecta_plus_ensure_foreign_key(
  'public.friend_requests'::regclass, 'recipient_id',
  'public.profiles'::regclass, 'id',
  'conecta_plus_friend_requests_recipient_fk'
);
select conecta_plus_private.conecta_plus_ensure_foreign_key(
  'public.conversation_members'::regclass, 'conversation_id',
  'public.conversations'::regclass, 'id',
  'conecta_plus_conversation_members_conversation_fk'
);
select conecta_plus_private.conecta_plus_ensure_foreign_key(
  'public.conversation_members'::regclass, 'user_id',
  'public.profiles'::regclass, 'id',
  'conecta_plus_conversation_members_user_fk'
);
select conecta_plus_private.conecta_plus_ensure_foreign_key(
  'public.messages'::regclass, 'conversation_id',
  'public.conversations'::regclass, 'id',
  'conecta_plus_messages_conversation_fk'
);
select conecta_plus_private.conecta_plus_ensure_foreign_key(
  'public.messages'::regclass, 'sender_id',
  'public.profiles'::regclass, 'id',
  'conecta_plus_messages_sender_fk'
);

create or replace function conecta_plus_private.is_conversation_member(
  p_conversation_id uuid
)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.conversation_members as member
    where member.conversation_id = p_conversation_id
      and member.user_id = (select auth.uid())
  );
$$;

create or replace function public.create_profile_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  safe_username text;
  fallback_username text;
  safe_display_name text;
begin
  safe_username := left(
    lower(
      regexp_replace(
        coalesce(new.raw_user_meta_data ->> 'username', ''),
        '[^a-z0-9_]',
        '',
        'g'
      )
    ),
    24
  );

  fallback_username :=
    'user_' || left(replace(new.id::text, '-', ''), 12);

  if char_length(safe_username) < 3
     or exists (
       select 1
       from public.profiles as existing_profile
       where lower(existing_profile.username) = lower(safe_username)
         and existing_profile.id <> new.id
     ) then
    safe_username := fallback_username;
  end if;

  safe_display_name := left(
    coalesce(
      nullif(trim(new.raw_user_meta_data ->> 'display_name'), ''),
      nullif(split_part(coalesce(new.email, ''), '@', 1), ''),
      'Pessoa'
    ),
    80
  );
  if char_length(safe_display_name) < 2 then
    safe_display_name := 'Pessoa';
  end if;

  insert into public.profiles (id, display_name, username)
  values (new.id, safe_display_name, safe_username)
  on conflict (id) do nothing;

  return new;
end;
$$;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

do $$
begin
  perform conecta_plus_private.conecta_plus_ensure_trigger(
    'auth',
    'users',
    'on_auth_user_created',
    'after insert',
    'public.create_profile_for_new_user()'::regprocedure,
    5
  );
  perform conecta_plus_private.conecta_plus_ensure_trigger(
    'public',
    'profiles',
    'profiles_set_updated_at',
    'before update',
    'public.set_updated_at()'::regprocedure,
    19
  );
  perform conecta_plus_private.conecta_plus_ensure_trigger(
    'public',
    'friend_requests',
    'friend_requests_set_updated_at',
    'before update',
    'public.set_updated_at()'::regprocedure,
    19
  );
end;
$$;

-- RLS permanece habilitado. Permissões de tabela são mínimas para o app.
alter table public.profiles enable row level security;
alter table public.friend_requests enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

revoke all on table public.profiles from public, anon, authenticated;
revoke all on table public.friend_requests from public, anon, authenticated;
revoke all on table public.conversations from public, anon, authenticated;
revoke all on table public.conversation_members from public, anon, authenticated;
revoke all on table public.messages from public, anon, authenticated;

grant select on table public.profiles to authenticated;
grant update (
  display_name,
  username,
  bio,
  city,
  avatar_url,
  is_discoverable,
  updated_at
) on table public.profiles to authenticated;
grant select on table public.friend_requests to authenticated;
grant select on table public.conversations to authenticated;
grant select on table public.conversation_members to authenticated;
grant select, insert on table public.messages to authenticated;

do $$
begin
  -- Permissive policies provide the intended app access.
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'profiles',
    'Signed-in users can see discoverable profiles and connections',
    'SELECT', 'PERMISSIVE',
    $policy$
      id = (select auth.uid())
      or is_discoverable
      or exists (
        select 1
        from public.friend_requests as request
        where request.status in ('pending', 'accepted')
          and (
            (request.sender_id = (select auth.uid())
              and request.recipient_id = profiles.id)
            or
            (request.recipient_id = (select auth.uid())
              and request.sender_id = profiles.id)
          )
      )
    $policy$,
    null
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'profiles',
    'Users can update only their own profile',
    'UPDATE', 'PERMISSIVE',
    'id = (select auth.uid())',
    'id = (select auth.uid())'
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'friend_requests',
    'Users can read requests they sent or received',
    'SELECT', 'PERMISSIVE',
    'sender_id = (select auth.uid()) or recipient_id = (select auth.uid())',
    null
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'conversations',
    'Conversation members can read their conversations',
    'SELECT', 'PERMISSIVE',
    'conecta_plus_private.is_conversation_member(id)',
    null
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'conversation_members',
    'Conversation members can read member rows',
    'SELECT', 'PERMISSIVE',
    'conecta_plus_private.is_conversation_member(conversation_id)',
    null
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'messages',
    'Conversation members can read messages',
    'SELECT', 'PERMISSIVE',
    'conecta_plus_private.is_conversation_member(conversation_id)',
    null
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'messages',
    'A member can send a message as themselves',
    'INSERT', 'PERMISSIVE',
    null,
    'sender_id = (select auth.uid()) and conecta_plus_private.is_conversation_member(conversation_id)'
  );

  -- Restrictive guards AND with any older permissive policies, so a broad
  -- preexisting policy cannot expose another user's profiles or messages.
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'profiles',
    'conecta_plus_guard_profiles_select',
    'SELECT', 'RESTRICTIVE',
    $policy$
      id = (select auth.uid())
      or is_discoverable
      or exists (
        select 1
        from public.friend_requests as request
        where request.status in ('pending', 'accepted')
          and (
            (request.sender_id = (select auth.uid())
              and request.recipient_id = profiles.id)
            or
            (request.recipient_id = (select auth.uid())
              and request.sender_id = profiles.id)
          )
      )
    $policy$,
    null
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'profiles',
    'conecta_plus_guard_profiles_update',
    'UPDATE', 'RESTRICTIVE',
    'id = (select auth.uid())',
    'id = (select auth.uid())'
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'friend_requests',
    'conecta_plus_guard_friend_requests_select',
    'SELECT', 'RESTRICTIVE',
    'sender_id = (select auth.uid()) or recipient_id = (select auth.uid())',
    null
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'conversations',
    'conecta_plus_guard_conversations_select',
    'SELECT', 'RESTRICTIVE',
    'conecta_plus_private.is_conversation_member(id)',
    null
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'conversation_members',
    'conecta_plus_guard_conversation_members_select',
    'SELECT', 'RESTRICTIVE',
    'conecta_plus_private.is_conversation_member(conversation_id)',
    null
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'messages',
    'conecta_plus_guard_messages_select',
    'SELECT', 'RESTRICTIVE',
    'conecta_plus_private.is_conversation_member(conversation_id)',
    null
  );
  perform conecta_plus_private.conecta_plus_ensure_policy(
    'public', 'messages',
    'conecta_plus_guard_messages_insert',
    'INSERT', 'RESTRICTIVE',
    null,
    'sender_id = (select auth.uid()) and conecta_plus_private.is_conversation_member(conversation_id)'
  );
end;
$$;

create or replace function public.send_friend_request(p_recipient_id uuid)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_request_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Entre na sua conta para enviar uma solicitação.';
  end if;
  if p_recipient_id is null or p_recipient_id = auth.uid() then
    raise exception 'Não é possível enviar uma solicitação para si mesmo.';
  end if;
  if not exists (
    select 1
    from public.profiles
    where id = p_recipient_id
      and is_discoverable = true
  ) then
    raise exception 'Este perfil não está disponível para novas solicitações.';
  end if;
  if exists (
    select 1
    from public.friend_requests
    where status in ('pending', 'accepted')
      and least(sender_id, recipient_id) = least(auth.uid(), p_recipient_id)
      and greatest(sender_id, recipient_id) = greatest(auth.uid(), p_recipient_id)
  ) then
    raise exception 'Já existe uma solicitação ou amizade entre estas contas.';
  end if;

  insert into public.friend_requests (sender_id, recipient_id)
  values (auth.uid(), p_recipient_id)
  returning id into new_request_id;

  return new_request_id;
end;
$$;

create or replace function public.respond_to_friend_request(
  p_request_id uuid,
  p_response text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if p_response is null or p_response not in ('accepted', 'declined') then
    raise exception 'Resposta inválida para a solicitação.';
  end if;

  update public.friend_requests
  set status = p_response
  where id = p_request_id
    and recipient_id = auth.uid()
    and status = 'pending';

  if not found then
    raise exception 'Solicitação não encontrada ou já respondida.';
  end if;
end;
$$;

create or replace function public.start_direct_conversation(
  p_other_user_id uuid
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  conversation_id uuid;
begin
  if current_user_id is null
     or p_other_user_id is null
     or p_other_user_id = current_user_id then
    raise exception 'Conversa inválida.';
  end if;

  if not exists (
    select 1
    from public.friend_requests
    where status = 'accepted'
      and (
        (sender_id = current_user_id and recipient_id = p_other_user_id)
        or (sender_id = p_other_user_id and recipient_id = current_user_id)
      )
  ) then
    raise exception 'Só é possível conversar com uma amizade aceita.';
  end if;

  select current_member.conversation_id
  into conversation_id
  from public.conversation_members as current_member
  join public.conversation_members as other_member
    on other_member.conversation_id = current_member.conversation_id
  where current_member.user_id = current_user_id
    and other_member.user_id = p_other_user_id
  limit 1;

  if conversation_id is null then
    insert into public.conversations default values
    returning id into conversation_id;

    insert into public.conversation_members (conversation_id, user_id)
    values
      (conversation_id, current_user_id),
      (conversation_id, p_other_user_id);
  end if;

  return conversation_id;
end;
$$;

create or replace function public.list_my_conversations()
returns table (
  conversation_id uuid,
  other_user_id uuid,
  other_display_name text,
  other_username text,
  other_avatar_url text,
  last_message text,
  last_message_at timestamptz
)
language sql
stable
security definer
set search_path = ''
as $$
  select
    mine.conversation_id,
    other_member.user_id,
    person.display_name,
    person.username,
    person.avatar_url,
    latest.body,
    latest.created_at
  from public.conversation_members as mine
  join public.conversation_members as other_member
    on other_member.conversation_id = mine.conversation_id
   and other_member.user_id <> (select auth.uid())
  join public.profiles as person
    on person.id = other_member.user_id
  left join lateral (
    select message.body, message.created_at
    from public.messages as message
    where message.conversation_id = mine.conversation_id
    order by message.created_at desc
    limit 1
  ) as latest on true
  where mine.user_id = (select auth.uid())
  order by coalesce(latest.created_at, now()) desc;
$$;

revoke all on function conecta_plus_private.is_conversation_member(uuid) from public, anon;
grant execute on function conecta_plus_private.is_conversation_member(uuid) to authenticated;

revoke all on function public.create_profile_for_new_user() from public, anon, authenticated;
revoke all on function public.set_updated_at() from public, anon, authenticated;
revoke all on function public.send_friend_request(uuid) from public, anon, authenticated;
revoke all on function public.respond_to_friend_request(uuid, text) from public, anon, authenticated;
revoke all on function public.start_direct_conversation(uuid) from public, anon, authenticated;
revoke all on function public.list_my_conversations() from public, anon, authenticated;

grant execute on function public.send_friend_request(uuid) to authenticated;
grant execute on function public.respond_to_friend_request(uuid, text) to authenticated;
grant execute on function public.start_direct_conversation(uuid) to authenticated;
grant execute on function public.list_my_conversations() to authenticated;

revoke all on function conecta_plus_private.conecta_plus_ensure_unique_index(regclass, text, text[]) from public, anon, authenticated;
revoke all on function conecta_plus_private.conecta_plus_ensure_foreign_key(regclass, text, regclass, text, text) from public, anon, authenticated;
revoke all on function conecta_plus_private.conecta_plus_ensure_check(regclass, text, text) from public, anon, authenticated;
revoke all on function conecta_plus_private.conecta_plus_ensure_policy(text, text, text, text, text, text, text) from public, anon, authenticated;
revoke all on function conecta_plus_private.conecta_plus_ensure_trigger(text, text, text, text, regprocedure, integer) from public, anon, authenticated;

-- Reexecutar não causa erro se as tabelas já estiverem na publicação.
do $$
begin
  if not exists (
    select 1 from pg_catalog.pg_publication
    where pubname = 'supabase_realtime'
  ) then
    raise exception 'A publicação supabase_realtime não existe neste projeto Supabase.';
  end if;

  if not exists (
    select 1 from pg_catalog.pg_publication
    where pubname = 'supabase_realtime'
      and puballtables
  ) then
    if not exists (
      select 1 from pg_catalog.pg_publication_tables
      where pubname = 'supabase_realtime'
        and schemaname = 'public'
        and tablename = 'messages'
    ) then
      execute 'alter publication supabase_realtime add table public.messages';
    end if;

    if not exists (
      select 1 from pg_catalog.pg_publication_tables
      where pubname = 'supabase_realtime'
        and schemaname = 'public'
        and tablename = 'friend_requests'
    ) then
      execute 'alter publication supabase_realtime add table public.friend_requests';
    end if;
  end if;
end;
$$;

commit;
