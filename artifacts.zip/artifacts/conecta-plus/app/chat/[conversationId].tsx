import { useEffect, useState } from 'react';
import { useLocalSearchParams, router } from 'expo-router';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Feather } from '@expo/vector-icons';
import { FlatList, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar, IconButton, InlineNotice, LoadingState, PageContainer } from '@/components/ConectaUI';
import { useAuth } from '@/context/AuthContext';
import { getFriendlyError } from '@/lib/errors';
import { fetchMessages, sendMessage, type Message } from '@/lib/social';
import { supabase } from '@/lib/supabase';
import { useColors } from '@/hooks/useColors';

export default function ChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { conversationId, name, otherId } = useLocalSearchParams<{
    conversationId: string;
    name?: string;
    otherId?: string;
  }>();
  const [body, setBody] = useState('');
  const [live, setLive] = useState(false);
  const [actionError, setActionError] = useState('');
  const queryKey = ['messages', conversationId];

  const messagesQuery = useQuery({
    queryKey,
    queryFn: () => fetchMessages(conversationId),
    enabled: Boolean(conversationId && user),
  });

  useEffect(() => {
    if (!supabase || !conversationId) return;
    const client = supabase;

    const channel = client
      .channel(`messages:${conversationId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `conversation_id=eq.${conversationId}`,
        },
        () => {
          void queryClient.invalidateQueries({ queryKey });
        },
      )
      .subscribe((status) => setLive(status === 'SUBSCRIBED'));

    return () => {
      setLive(false);
      void client.removeChannel(channel);
    };
  }, [conversationId, queryClient]);

  const sendMutation = useMutation({
    mutationFn: () => sendMessage(conversationId, user!.id, body),
    onSuccess: async () => {
      setBody('');
      setActionError('');
      await queryClient.invalidateQueries({ queryKey });
    },
    onError: (error) => setActionError(getFriendlyError(error)),
  });

  const messages = messagesQuery.data ?? [];
  const otherName = Array.isArray(name) ? name[0] : name;
  const otherUserId = Array.isArray(otherId) ? otherId[0] : otherId;

  return (
    <PageContainer style={styles.page}>
      <View style={[styles.header, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <IconButton icon="arrow-left" label="Voltar" onPress={() => router.back()} testID="chat-back" />
        <Avatar name={otherName || 'Conversa'} size={40} />
        <View style={styles.headerText}>
          <Text style={[styles.headerName, { color: colors.foreground }]} numberOfLines={1}>
            {otherName || 'Conversa'}
          </Text>
          <View style={styles.liveRow}>
            <View style={[styles.liveDot, { backgroundColor: live ? colors.primary : colors.mutedForeground }]} />
            <Text style={[styles.liveText, { color: colors.mutedForeground }]}>
              {live ? 'Mensagens ao vivo' : 'Conectando…'}
            </Text>
          </View>
        </View>
        <Feather name="shield" size={18} color={colors.primary} />
      </View>

      {messagesQuery.error ? (
        <View style={styles.errorWrap}>
          <InlineNotice
            tone="warning"
            title="Mensagens indisponíveis"
            body={getFriendlyError(messagesQuery.error)}
          />
        </View>
      ) : null}
      {actionError ? (
        <View style={styles.errorWrap}>
          <InlineNotice tone="warning" title="Mensagem não enviada" body={actionError} />
        </View>
      ) : null}
      {messagesQuery.isLoading ? <LoadingState label="Carregando mensagens…" /> : null}

      <KeyboardAvoidingView
        style={styles.keyboardArea}
        behavior="padding"
        keyboardVerticalOffset={0}
      >
        <FlatList
          data={messages}
          keyExtractor={(item) => item.id}
          inverted
          renderItem={({ item }) => (
            <MessageBubble message={item} own={item.sender_id === user?.id} />
          )}
          contentContainerStyle={styles.messageList}
          keyboardDismissMode="interactive"
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            !messagesQuery.isLoading && !messagesQuery.error ? (
              <View style={styles.emptyMessage}>
                <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
                  Diga oi para começar
                </Text>
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                  As mensagens desta conversa são privadas para vocês dois.
                </Text>
              </View>
            ) : null
          }
        />
        <View
          style={[
            styles.composer,
            {
              backgroundColor: colors.card,
              borderTopColor: colors.border,
              paddingBottom: Platform.OS === 'web' ? 34 : Math.max(insets.bottom, 12),
            },
          ]}
        >
          <TextInput
            accessibilityLabel="Escrever mensagem"
            value={body}
            onChangeText={setBody}
            placeholder="Escreva uma mensagem…"
            placeholderTextColor={colors.mutedForeground}
            style={[
              styles.messageInput,
              { backgroundColor: colors.secondary, color: colors.foreground },
            ]}
            multiline
            maxLength={3000}
            testID="chat-message-input"
          />
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Enviar mensagem"
            accessibilityState={{ disabled: !body.trim() || sendMutation.isPending }}
            disabled={!body.trim() || sendMutation.isPending}
            onPress={() => sendMutation.mutate()}
            style={({ pressed }) => [
              styles.sendButton,
              { backgroundColor: colors.primary },
              (!body.trim() || sendMutation.isPending) && styles.disabled,
              pressed && styles.pressed,
            ]}
            testID="chat-send"
          >
            <Feather name="arrow-up" size={20} color={colors.primaryForeground} />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </PageContainer>
  );
}

function MessageBubble({ message, own }: { message: Message; own: boolean }) {
  const colors = useColors();
  const time = new Intl.DateTimeFormat('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(message.created_at));

  return (
    <View style={[styles.bubbleRow, own ? styles.ownRow : styles.theirRow]}>
      <View
        style={[
          styles.bubble,
          own
            ? { backgroundColor: colors.primary }
            : { backgroundColor: colors.card, borderColor: colors.border },
          !own && styles.otherBubble,
        ]}
      >
        <Text style={[styles.bubbleText, { color: own ? colors.primaryForeground : colors.foreground }]}>
          {message.body}
        </Text>
        <Text style={[styles.time, { color: own ? colors.primaryForeground : colors.mutedForeground }]}>
          {time}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  header: { minHeight: 62, flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 14, borderBottomWidth: 1 },
  headerText: { flex: 1, gap: 3 },
  headerName: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  liveRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  liveText: { fontFamily: 'Inter_400Regular', fontSize: 10 },
  keyboardArea: { flex: 1 },
  messageList: { padding: 16, gap: 10, flexGrow: 1, justifyContent: 'flex-end' },
  bubbleRow: { width: '100%', flexDirection: 'row' },
  ownRow: { justifyContent: 'flex-end' },
  theirRow: { justifyContent: 'flex-start' },
  bubble: { maxWidth: '82%', borderRadius: 18, paddingHorizontal: 13, paddingVertical: 10, gap: 5, borderWidth: 1 },
  otherBubble: { borderBottomLeftRadius: 5 },
  bubbleText: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 20 },
  time: { fontFamily: 'Inter_400Regular', fontSize: 9, alignSelf: 'flex-end' },
  emptyMessage: { padding: 22, alignItems: 'center', gap: 6, transform: [{ scaleY: -1 }] },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18, textAlign: 'center' },
  composer: { minHeight: 68, borderTopWidth: 1, paddingHorizontal: 12, paddingTop: 10, flexDirection: 'row', alignItems: 'flex-end', gap: 9 },
  messageInput: { flex: 1, maxHeight: 120, minHeight: 44, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 11, fontFamily: 'Inter_400Regular', fontSize: 14 },
  sendButton: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center', borderRadius: 15, marginBottom: 1 },
  disabled: { opacity: 0.5 },
  pressed: { opacity: 0.78 },
  errorWrap: { paddingHorizontal: 16, paddingTop: 10 },
});
