import { useEffect, useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { Avatar, Field, InlineNotice, PageContainer, PrimaryButton, ScreenHeading } from '@/components/ConectaUI';
import { useAuth } from '@/context/AuthContext';
import { getFriendlyError } from '@/lib/errors';
import { useColors } from '@/hooks/useColors';
import { StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { profile, refreshProfile, saveProfile } = useAuth();
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [city, setCity] = useState('');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!profile) return;
    setDisplayName(profile.display_name);
    setUsername(profile.username);
    setCity(profile.city ?? '');
    setBio(profile.bio ?? '');
    setAvatarUrl(profile.avatar_url ?? '');
  }, [profile?.id, profile?.updated_at]);

  const saveMutation = useMutation({
    mutationFn: () =>
      saveProfile({
        display_name: displayName.trim(),
        username: username.trim().toLowerCase(),
        city: city.trim() || null,
        bio: bio.trim() || null,
        avatar_url: avatarUrl.trim() || null,
      }),
    onSuccess: () => {
      setError('');
      setMessage('Seu perfil foi atualizado.');
    },
    onError: (cause) => {
      setMessage('');
      setError(getFriendlyError(cause));
    },
  });

  return (
    <PageContainer>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Math.max(insets.bottom, 24) + 24 },
        ]}
        bottomOffset={70}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <ScreenHeading
          eyebrow="Seu espaço"
          title="Meu perfil"
          subtitle="Mostre um pouco de quem você é."
        />

        <View style={[styles.identityCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Avatar name={displayName || 'Seu perfil'} imageUrl={avatarUrl || null} size={70} />
          <View style={styles.identityText}>
            <Text style={[styles.identityName, { color: colors.foreground }]}>
              {displayName || 'Seu nome'}
            </Text>
            <Text style={[styles.identityUsername, { color: colors.mutedForeground }]}>
              {username ? `@${username}` : 'Seu perfil no Conecta+'}
            </Text>
          </View>
        </View>

        {error ? <InlineNotice tone="warning" title="Não foi possível salvar" body={error} /> : null}
        {message ? <InlineNotice tone="success" title="Tudo certo" body={message} /> : null}

        <View style={styles.form}>
          <Field
            label="Nome"
            icon="user"
            value={displayName}
            onChangeText={setDisplayName}
            placeholder="Seu nome"
            autoCapitalize="words"
            maxLength={80}
            testID="profile-display-name"
          />
          <Field
            label="Nome de usuário"
            icon="at-sign"
            value={username}
            onChangeText={(value) =>
              setUsername(value.toLowerCase().replace(/[^a-z0-9_]/g, ''))
            }
            placeholder="seunome"
            autoCapitalize="none"
            maxLength={24}
            testID="profile-username"
          />
          <Field
            label="Cidade"
            icon="map-pin"
            value={city}
            onChangeText={setCity}
            placeholder="Sua cidade"
            autoCapitalize="words"
            maxLength={100}
            testID="profile-city"
          />
          <Field
            label="Descrição"
            icon="edit-3"
            value={bio}
            onChangeText={setBio}
            placeholder="Conte um pouco sobre você"
            multiline
            textAlignVertical="top"
            style={styles.bioInput}
            maxLength={300}
            testID="profile-bio"
          />
          <Field
            label="Link da foto (opcional)"
            icon="image"
            value={avatarUrl}
            onChangeText={setAvatarUrl}
            placeholder="https://…"
            autoCapitalize="none"
            keyboardType="url"
            maxLength={500}
            testID="profile-avatar-url"
          />
          <Text style={[styles.helper, { color: colors.mutedForeground }]}>
            A imagem precisa estar em um endereço público. O Conecta+ não armazena fotos nesta etapa.
          </Text>
          <PrimaryButton
            title="Salvar alterações"
            icon="check"
            onPress={() => {
              setMessage('');
              saveMutation.mutate();
            }}
            loading={saveMutation.isPending}
            testID="profile-save"
          />
        </View>
      </KeyboardAwareScrollViewCompat>
    </PageContainer>
  );
}

const styles = StyleSheet.create({
  content: { flexGrow: 1, padding: 20, gap: 18 },
  identityCard: { flexDirection: 'row', alignItems: 'center', gap: 14, borderWidth: 1, borderRadius: 20, padding: 15 },
  identityText: { flex: 1, gap: 5 },
  identityName: { fontFamily: 'Inter_600SemiBold', fontSize: 16 },
  identityUsername: { fontFamily: 'Inter_400Regular', fontSize: 13 },
  form: { gap: 14 },
  bioInput: { minHeight: 104, paddingTop: 13 },
  helper: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17, marginTop: -5 },
});
