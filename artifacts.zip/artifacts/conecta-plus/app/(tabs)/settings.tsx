import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import { InlineNotice, PageContainer, ScreenHeading } from '@/components/ConectaUI';
import { useAuth } from '@/context/AuthContext';
import { getFriendlyError } from '@/lib/errors';
import { useColors } from '@/hooks/useColors';

export default function SettingsScreen() {
  const colors = useColors();
  const { user, profile, saveProfile, signOut } = useAuth();
  const [visible, setVisible] = useState(profile?.is_discoverable ?? true);
  const [error, setError] = useState('');
  const [signedOutError, setSignedOutError] = useState('');

  const privacyMutation = useMutation({
    mutationFn: (nextValue: boolean) =>
      saveProfile({ is_discoverable: nextValue }),
    onMutate: (nextValue) => setVisible(nextValue),
    onError: (cause, previousValue) => {
      setVisible(!previousValue);
      setError(getFriendlyError(cause));
    },
    onSuccess: () => setError(''),
  });

  const handleSignOut = async () => {
    setSignedOutError('');
    try {
      await signOut();
      router.replace('/(auth)/login');
    } catch (cause) {
      setSignedOutError(getFriendlyError(cause));
    }
  };

  return (
    <PageContainer>
      <View style={styles.content}>
        <ScreenHeading
          eyebrow="Personalize"
          title="Configurações"
          subtitle="Controle sua conta e sua experiência."
        />

        {error ? <InlineNotice tone="warning" title="Privacidade não atualizada" body={error} /> : null}
        {signedOutError ? (
          <InlineNotice tone="warning" title="Não foi possível sair" body={signedOutError} />
        ) : null}

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>
          CONTA E SEGURANÇA
        </Text>
        <View style={[styles.settingCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.settingIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="mail" size={17} color={colors.primary} />
          </View>
          <View style={styles.settingText}>
            <Text style={[styles.settingTitle, { color: colors.foreground }]}>E-mail da conta</Text>
            <Text style={[styles.settingDescription, { color: colors.mutedForeground }]} numberOfLines={1}>
              {user?.email ?? 'Não informado'}
            </Text>
          </View>
        </View>

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>
          PRIVACIDADE
        </Text>
        <View style={[styles.settingCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.settingIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="eye" size={17} color={colors.primary} />
          </View>
          <View style={styles.settingText}>
            <Text style={[styles.settingTitle, { color: colors.foreground }]}>
              Aparecer em Descobrir
            </Text>
            <Text style={[styles.settingDescription, { color: colors.mutedForeground }]}>
              {visible ? 'Seu perfil pode ser encontrado por outras pessoas.' : 'Seu perfil está oculto da descoberta.'}
            </Text>
          </View>
          <Switch
            accessibilityLabel="Aparecer em Descobrir"
            value={visible}
            onValueChange={(value) => privacyMutation.mutate(value)}
            disabled={privacyMutation.isPending || !profile}
            trackColor={{ false: colors.border, true: colors.primary }}
            thumbColor={colors.primaryForeground}
            testID="privacy-discoverable"
          />
        </View>

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>
          SOBRE
        </Text>
        <View style={[styles.infoCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.settingIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="heart" size={17} color={colors.primary} />
          </View>
          <View style={styles.settingText}>
            <Text style={[styles.settingTitle, { color: colors.foreground }]}>Conecta+</Text>
            <Text style={[styles.settingDescription, { color: colors.mutedForeground }]}>
              Uma rede para aproximar pessoas.
            </Text>
          </View>
          <Text style={[styles.version, { color: colors.mutedForeground }]}>1.0</Text>
        </View>

        <Pressable
          accessibilityRole="button"
          accessibilityState={{ busy: privacyMutation.isPending }}
          onPress={() => void handleSignOut()}
          style={({ pressed }) => [
            styles.signOut,
            { borderColor: colors.border },
            pressed && styles.pressed,
          ]}
          testID="settings-sign-out"
        >
          <Feather name="log-out" size={18} color={colors.destructive} />
          <Text style={[styles.signOutText, { color: colors.destructive }]}>Sair da conta</Text>
        </Pressable>
      </View>
    </PageContainer>
  );
}

const styles = StyleSheet.create({
  content: { flex: 1, padding: 20, gap: 13 },
  sectionLabel: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2, marginTop: 8 },
  settingCard: { minHeight: 73, flexDirection: 'row', alignItems: 'center', gap: 12, borderRadius: 18, borderWidth: 1, paddingHorizontal: 13, paddingVertical: 12 },
  infoCard: { minHeight: 68, flexDirection: 'row', alignItems: 'center', gap: 12, borderRadius: 18, borderWidth: 1, paddingHorizontal: 13, paddingVertical: 11 },
  settingIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  settingText: { flex: 1, gap: 4 },
  settingTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  settingDescription: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16 },
  version: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  signOut: { minHeight: 52, marginTop: 'auto', borderWidth: 1, borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 },
  signOutText: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  pressed: { opacity: 0.75 },
});
