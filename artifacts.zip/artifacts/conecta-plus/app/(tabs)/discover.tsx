import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Feather } from '@expo/vector-icons';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Avatar, EmptyState, InlineNotice, LoadingState, PageContainer, PrimaryButton, ScreenHeading } from '@/components/ConectaUI';
import { useAuth } from '@/context/AuthContext';
import { getFriendlyError } from '@/lib/errors';
import { fetchDiscoverProfiles, sendFriendRequest, type SocialProfile } from '@/lib/social';
import { useColors } from '@/hooks/useColors';

export default function DiscoverScreen() {
  const colors = useColors();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [search, setSearch] = useState('');
  const [actionError, setActionError] = useState('');
  const userId = user?.id;

  const profilesQuery = useQuery({
    queryKey: ['discover', userId],
    queryFn: () => fetchDiscoverProfiles(userId!),
    enabled: Boolean(userId),
  });

  const requestMutation = useMutation({
    mutationFn: (profile: SocialProfile) => sendFriendRequest(profile.id),
    onSuccess: async () => {
      setActionError('');
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['discover', userId] }),
        queryClient.invalidateQueries({ queryKey: ['friend-overview', userId] }),
      ]);
    },
    onError: (error) => setActionError(getFriendlyError(error)),
  });

  const visibleProfiles = useMemo(() => {
    const searchText = search.trim().toLocaleLowerCase('pt-BR');
    if (!searchText) return profilesQuery.data ?? [];
    return (profilesQuery.data ?? []).filter((profile) =>
      `${profile.display_name} ${profile.username} ${profile.city ?? ''}`
        .toLocaleLowerCase('pt-BR')
        .includes(searchText),
    );
  }, [profilesQuery.data, search]);

  return (
    <PageContainer>
      <FlatList
        data={visibleProfiles}
        keyExtractor={(profile) => profile.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <View style={styles.headerContent}>
            <ScreenHeading
              eyebrow="Conecta+"
              title="Descobrir"
              subtitle="Conheça pessoas novas, no seu ritmo."
            />
            <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Feather name="search" size={17} color={colors.mutedForeground} />
              <TextInput
                accessibilityLabel="Buscar por nome, usuário ou cidade"
                value={search}
                onChangeText={setSearch}
                placeholder="Nome, usuário ou cidade"
                placeholderTextColor={colors.mutedForeground}
                style={[styles.searchInput, { color: colors.foreground }]}
                autoCapitalize="none"
                returnKeyType="search"
                testID="discover-search"
              />
            </View>
            {actionError ? (
              <InlineNotice tone="warning" title="Solicitação não enviada" body={actionError} />
            ) : null}
            {profilesQuery.isLoading ? <LoadingState label="Buscando pessoas…" /> : null}
            {profilesQuery.error ? (
              <InlineNotice
                tone="warning"
                title="Não foi possível carregar os perfis"
                body={getFriendlyError(profilesQuery.error)}
              />
            ) : null}
            {!profilesQuery.isLoading && !profilesQuery.error && visibleProfiles.length === 0 ? (
              <EmptyState
                icon="compass"
                title={search ? 'Ninguém encontrado' : 'Novas conexões vêm por aí'}
                body={
                  search
                    ? 'Tente outro nome, usuário ou cidade.'
                    : 'Quando outras pessoas criarem perfis visíveis, elas aparecerão aqui.'
                }
              />
            ) : null}
          </View>
        }
        renderItem={({ item }) => (
          <View style={[styles.profileCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.personRow}>
              <Avatar name={item.display_name} imageUrl={item.avatar_url} size={56} />
              <View style={styles.personText}>
                <Text style={[styles.personName, { color: colors.foreground }]} numberOfLines={1}>
                  {item.display_name}
                </Text>
                <Text style={[styles.username, { color: colors.mutedForeground }]} numberOfLines={1}>
                  @{item.username}
                </Text>
                {item.city ? (
                  <Text style={[styles.city, { color: colors.mutedForeground }]} numberOfLines={1}>
                    <Feather name="map-pin" size={12} color={colors.mutedForeground} /> {item.city}
                  </Text>
                ) : null}
              </View>
              <View style={[styles.sparkle, { backgroundColor: colors.secondary }]}>
                <Feather name="heart" size={16} color={colors.primary} />
              </View>
            </View>
            {item.bio ? (
              <Text style={[styles.bio, { color: colors.foreground }]}>{item.bio}</Text>
            ) : null}
            <PrimaryButton
              title="Enviar solicitação"
              icon="user-plus"
              onPress={() => requestMutation.mutate(item)}
              loading={requestMutation.isPending && requestMutation.variables?.id === item.id}
              disabled={requestMutation.isPending}
              testID={`friend-request-${item.id}`}
            />
          </View>
        )}
        ListFooterComponent={<View style={{ height: 18 }} />}
      />
    </PageContainer>
  );
}

const styles = StyleSheet.create({
  list: { padding: 20, paddingBottom: 28, gap: 14 },
  headerContent: { gap: 18, marginBottom: 2 },
  searchBox: {
    height: 48,
    borderWidth: 1,
    borderRadius: 15,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 14,
  },
  searchInput: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 14, minHeight: 44 },
  profileCard: { borderRadius: 22, borderWidth: 1, padding: 16, gap: 14 },
  personRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  personText: { flex: 1, gap: 3 },
  personName: { fontFamily: 'Inter_600SemiBold', fontSize: 16 },
  username: { fontFamily: 'Inter_400Regular', fontSize: 12 },
  city: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 2 },
  sparkle: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  bio: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20 },
});
