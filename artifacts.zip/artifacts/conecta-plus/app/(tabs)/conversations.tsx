import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Avatar, EmptyState, InlineNotice, LoadingState, PageContainer, PrimaryButton, QuietButton, ScreenHeading } from '@/components/ConectaUI';
import { useAuth } from '@/context/AuthContext';
import { getFriendlyError } from '@/lib/errors';
import {
  fetchConversations,
  fetchFriendOverview,
  respondToFriendRequest,
  startDirectConversation,
  type FriendRequest,
  type SocialProfile,
} from '@/lib/social';
import { useColors } from '@/hooks/useColors';

type Section = 'messages' | 'requests' | 'friends';

export default function ConversationsScreen() {
  const colors = useColors();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [section, setSection] = useState<Section>('messages');
  const [actionError, setActionError] = useState('');
  const userId = user?.id;

  const overviewQuery = useQuery({
    queryKey: ['friend-overview', userId],
    queryFn: () => fetchFriendOverview(userId!),
    enabled: Boolean(userId),
  });
  const conversationsQuery = useQuery({
    queryKey: ['conversations', userId],
    queryFn: fetchConversations,
    enabled: Boolean(userId),
  });

  const invalidateSocial = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['friend-overview', userId] }),
      queryClient.invalidateQueries({ queryKey: ['conversations', userId] }),
      queryClient.invalidateQueries({ queryKey: ['discover', userId] }),
    ]);
  };

  const responseMutation = useMutation({
    mutationFn: ({
      request,
      response,
    }: {
      request: FriendRequest;
      response: 'accepted' | 'declined';
    }) => respondToFriendRequest(request.id, response),
    onSuccess: async () => {
      setActionError('');
      await invalidateSocial();
    },
    onError: (error) => setActionError(getFriendlyError(error)),
  });

  const openConversationMutation = useMutation({
    mutationFn: async (person: SocialProfile) => ({
      person,
      conversationId: await startDirectConversation(person.id),
    }),
    onSuccess: ({ person, conversationId }) => {
      router.push({
        pathname: '/chat/[conversationId]',
        params: {
          conversationId,
          otherId: person.id,
          name: person.display_name,
        },
      });
    },
    onError: (error) => setActionError(getFriendlyError(error)),
  });

  const overview = overviewQuery.data;
  const incoming = overview?.incoming ?? [];
  const friends = overview?.friends ?? [];
  const conversations = conversationsQuery.data ?? [];
  const isLoading = overviewQuery.isLoading || conversationsQuery.isLoading;
  const queryError = overviewQuery.error ?? conversationsQuery.error;

  return (
    <PageContainer>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <ScreenHeading
          eyebrow="Sua rede"
          title="Conversas"
          subtitle="Amizades e mensagens em um só lugar."
          right={
            <View style={[styles.headerIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="message-circle" size={19} color={colors.primary} />
            </View>
          }
        />

        <View style={[styles.sectionTabs, { backgroundColor: colors.secondary }]}>
          <SectionButton
            title="Conversas"
            active={section === 'messages'}
            count={conversations.length}
            onPress={() => setSection('messages')}
          />
          <SectionButton
            title="Solicitações"
            active={section === 'requests'}
            count={incoming.length}
            onPress={() => setSection('requests')}
          />
          <SectionButton
            title="Amizades"
            active={section === 'friends'}
            count={friends.length}
            onPress={() => setSection('friends')}
          />
        </View>

        {actionError ? (
          <InlineNotice tone="warning" title="Ação não concluída" body={actionError} />
        ) : null}
        {queryError ? (
          <InlineNotice
            tone="warning"
            title="Não foi possível carregar"
            body={getFriendlyError(queryError)}
          />
        ) : null}
        {isLoading ? <LoadingState label="Carregando conversas…" /> : null}

        {!isLoading && !queryError && section === 'messages' ? (
          conversations.length === 0 ? (
            <EmptyState
              icon="message-circle"
              title="Suas conversas começam com uma amizade"
              body="Aceite uma solicitação ou conheça alguém novo para iniciar uma conversa."
              action={
                <QuietButton
                  title="Conhecer pessoas"
                  icon="compass"
                  onPress={() => router.push('/(tabs)/discover')}
                />
              }
            />
          ) : (
            <View style={styles.rows}>
              {conversations.map((conversation) => (
                <Pressable
                  key={conversation.conversation_id}
                  accessibilityRole="button"
                  testID={`conversation-${conversation.conversation_id}`}
                  onPress={() =>
                    router.push({
                      pathname: '/chat/[conversationId]',
                      params: {
                        conversationId: conversation.conversation_id,
                        otherId: conversation.other_user_id,
                        name: conversation.other_display_name,
                      },
                    })
                  }
                  style={({ pressed }) => [
                    styles.personRow,
                    { backgroundColor: colors.card, borderColor: colors.border },
                    pressed && styles.pressed,
                  ]}
                >
                  <Avatar
                    name={conversation.other_display_name}
                    imageUrl={conversation.other_avatar_url}
                    size={52}
                  />
                  <View style={styles.personDetails}>
                    <Text style={[styles.name, { color: colors.foreground }]} numberOfLines={1}>
                      {conversation.other_display_name}
                    </Text>
                    <Text style={[styles.preview, { color: colors.mutedForeground }]} numberOfLines={1}>
                      {conversation.last_message || `@${conversation.other_username}`}
                    </Text>
                  </View>
                  <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
                </Pressable>
              ))}
            </View>
          )
        ) : null}

        {!isLoading && !queryError && section === 'requests' ? (
          incoming.length === 0 ? (
            <EmptyState
              icon="user-plus"
              title="Nenhuma solicitação por enquanto"
              body="Quando alguém quiser se conectar, a solicitação aparece aqui."
            />
          ) : (
            <View style={styles.rows}>
              {incoming.map((request) => (
                <RequestRow
                  key={request.id}
                  request={request}
                  onAccept={() =>
                    responseMutation.mutate({ request, response: 'accepted' })
                  }
                  onDecline={() =>
                    responseMutation.mutate({ request, response: 'declined' })
                  }
                  busy={responseMutation.isPending}
                />
              ))}
            </View>
          )
        ) : null}

        {!isLoading && !queryError && section === 'friends' ? (
          friends.length === 0 ? (
            <EmptyState
              icon="users"
              title="Sua lista começa aqui"
              body="Quando uma solicitação for aceita, sua amizade aparecerá nesta lista."
            />
          ) : (
            <View style={styles.rows}>
              {friends.map((friend) => (
                <View
                  key={friend.id}
                  style={[
                    styles.friendRow,
                    { backgroundColor: colors.card, borderColor: colors.border },
                  ]}
                >
                  <Avatar name={friend.display_name} imageUrl={friend.avatar_url} size={50} />
                  <View style={styles.personDetails}>
                    <Text style={[styles.name, { color: colors.foreground }]} numberOfLines={1}>
                      {friend.display_name}
                    </Text>
                    <Text style={[styles.preview, { color: colors.mutedForeground }]} numberOfLines={1}>
                      @{friend.username}
                    </Text>
                  </View>
                  <QuietButton
                    title="Conversar"
                    icon="message-circle"
                    onPress={() => openConversationMutation.mutate(friend)}
                    disabled={openConversationMutation.isPending}
                  />
                </View>
              ))}
            </View>
          )
        ) : null}
      </ScrollView>
    </PageContainer>
  );
}

function SectionButton({
  title,
  active,
  count,
  onPress,
}: {
  title: string;
  active: boolean;
  count: number;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="tab"
      accessibilityState={{ selected: active }}
      onPress={onPress}
      style={[
        styles.sectionButton,
        active && { backgroundColor: colors.card },
      ]}
    >
      <Text style={[styles.sectionText, { color: active ? colors.primary : colors.mutedForeground }]}>
        {title}
      </Text>
      {count > 0 ? (
        <Text style={[styles.count, { color: active ? colors.primary : colors.mutedForeground }]}>
          {count > 99 ? '99+' : count}
        </Text>
      ) : null}
    </Pressable>
  );
}

function RequestRow({
  request,
  onAccept,
  onDecline,
  busy,
}: {
  request: FriendRequest;
  onAccept: () => void;
  onDecline: () => void;
  busy: boolean;
}) {
  const colors = useColors();
  return (
    <View style={[styles.requestCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={styles.personRow}>
        <Avatar name={request.person.display_name} imageUrl={request.person.avatar_url} size={50} />
        <View style={styles.personDetails}>
          <Text style={[styles.name, { color: colors.foreground }]} numberOfLines={1}>
            {request.person.display_name}
          </Text>
          <Text style={[styles.preview, { color: colors.mutedForeground }]}>
            @{request.person.username} quer se conectar
          </Text>
        </View>
      </View>
      <View style={styles.actions}>
        <PrimaryButton
          title="Aceitar"
          icon="check"
          onPress={onAccept}
          disabled={busy}
          testID={`accept-friend-${request.id}`}
        />
        <QuietButton
          title="Agora não"
          icon="x"
          onPress={onDecline}
          disabled={busy}
          testID={`decline-friend-${request.id}`}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 30, gap: 20 },
  headerIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  sectionTabs: { flexDirection: 'row', padding: 4, borderRadius: 16, gap: 2 },
  sectionButton: { flex: 1, minHeight: 40, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, paddingHorizontal: 5 },
  sectionText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  count: { fontFamily: 'Inter_700Bold', fontSize: 10 },
  rows: { gap: 10 },
  personRow: { flexDirection: 'row', alignItems: 'center', gap: 12, borderRadius: 18, borderWidth: 1, padding: 13 },
  friendRow: { flexDirection: 'row', alignItems: 'center', gap: 11, borderRadius: 18, borderWidth: 1, padding: 12 },
  personDetails: { flex: 1, gap: 4 },
  name: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  preview: { fontFamily: 'Inter_400Regular', fontSize: 12 },
  requestCard: { borderWidth: 1, borderRadius: 18, padding: 13, gap: 12 },
  actions: { flexDirection: 'row', gap: 8 },
  pressed: { opacity: 0.8 },
});
