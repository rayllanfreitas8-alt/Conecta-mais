// Backward-compatible alias for links configured as conecta-plus://callback.
export { default } from './auth/callback';
