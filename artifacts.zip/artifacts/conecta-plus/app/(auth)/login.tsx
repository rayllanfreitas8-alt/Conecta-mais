import { useState } from 'react';
import { Link, Redirect } from 'expo-router';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { BrandMark, Field, InlineNotice, PageContainer, PrimaryButton } from '@/components/ConectaUI';
import { useAuth } from '@/context/AuthContext';
import { getFriendlyError } from '@/lib/errors';
import { useColors } from '@/hooks/useColors';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function LoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, signIn, loading, supabaseReady } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  if (user && !loading) return <Redirect href="/(tabs)/discover" />;

  const handleSignIn = async () => {
    setError('');
    setBusy(true);
    try {
      await signIn(email, password);
    } catch (cause) {
      setError(getFriendlyError(cause));
    } finally {
      setBusy(false);
    }
  };

  return (
    <PageContainer style={{ backgroundColor: colors.background }}>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: 28,
            paddingBottom: insets.bottom + 30,
          },
        ]}
        bottomOffset={28}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <BrandMark />
        <View style={styles.intro}>
          <Text style={[styles.title, { color: colors.foreground }]}>
            Encontre novas conexões.
          </Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            Entre para conhecer pessoas novas, no seu ritmo.
          </Text>
        </View>

        {!supabaseReady ? (
          <InlineNotice
            tone="warning"
            title="Supabase ainda não conectado"
            body="A tela está pronta. Configure a URL e a chave pública do seu projeto para ativar o cadastro e o login."
          />
        ) : null}

        {error ? (
          <InlineNotice tone="warning" title="Não foi possível entrar" body={error} />
        ) : null}

        <View style={styles.form}>
          <Field
            label="E-mail"
            icon="mail"
            value={email}
            onChangeText={setEmail}
            placeholder="voce@exemplo.com"
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
            textContentType="emailAddress"
            returnKeyType="next"
            testID="login-email"
          />
          <Field
            label="Senha"
            icon="lock"
            value={password}
            onChangeText={setPassword}
            placeholder="Sua senha"
            secureTextEntry
            autoCapitalize="none"
            autoComplete="password"
            textContentType="password"
            onSubmitEditing={handleSignIn}
            returnKeyType="go"
            testID="login-password"
          />
          <PrimaryButton
            title="Entrar"
            icon="arrow-right"
            onPress={() => void handleSignIn()}
            loading={busy}
            testID="login-submit"
          />
        </View>

        <View style={styles.registerRow}>
          <Text style={[styles.registerText, { color: colors.mutedForeground }]}>
            Ainda não tem conta?
          </Text>
          <Link href="/(auth)/register" asChild>
            <Pressable accessibilityRole="button" testID="go-to-register">
              <Text style={[styles.registerLink, { color: colors.primary }]}>
                Criar cadastro
              </Text>
            </Pressable>
          </Link>
        </View>

        <View style={[styles.footer, { borderTopColor: colors.border }]}>
          <Text style={[styles.footerText, { color: colors.mutedForeground }]}>
            Seus dados ficam protegidos pelas regras de acesso do Supabase.
          </Text>
        </View>
      </KeyboardAwareScrollViewCompat>
    </PageContainer>
  );
}

const styles = StyleSheet.create({
  content: { flexGrow: 1, paddingHorizontal: 24, gap: 24, justifyContent: 'center' },
  intro: { gap: 8, marginTop: 10 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 31, lineHeight: 38, letterSpacing: -1 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 15, lineHeight: 23 },
  form: { gap: 16 },
  registerRow: { flexDirection: 'row', justifyContent: 'center', gap: 5, flexWrap: 'wrap' },
  registerText: { fontFamily: 'Inter_400Regular', fontSize: 13 },
  registerLink: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  footer: { borderTopWidth: 1, paddingTop: 18, alignItems: 'center' },
  footerText: { fontFamily: 'Inter_400Regular', fontSize: 11, textAlign: 'center', lineHeight: 17 },
});
