import { useState } from 'react';
import { Link, Redirect, router } from 'expo-router';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { BrandMark, Field, InlineNotice, PageContainer, PrimaryButton } from '@/components/ConectaUI';
import { useAuth } from '@/context/AuthContext';
import { getFriendlyError } from '@/lib/errors';
import { useColors } from '@/hooks/useColors';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function RegisterScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, signUp, loading, supabaseReady } = useAuth();
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  if (user && !loading) return <Redirect href="/(tabs)/discover" />;

  const handleRegister = async () => {
    setError('');
    setSuccess('');
    const normalizedUsername = username.trim().toLowerCase();

    if (displayName.trim().length < 2 || displayName.trim().length > 80) {
      setError('Seu nome deve ter entre 2 e 80 caracteres.');
      return;
    }
    if (!/^[a-z0-9_]{3,24}$/.test(normalizedUsername)) {
      setError('O nome de usuário deve ter de 3 a 24 caracteres: letras, números ou sublinhado.');
      return;
    }
    if (password.length < 8) {
      setError('A senha precisa ter pelo menos 8 caracteres.');
      return;
    }
    if (password !== confirmation) {
      setError('As senhas não são iguais.');
      return;
    }

    setBusy(true);
    try {
      const result = await signUp(
        email,
        password,
        displayName,
        normalizedUsername,
      );
      if (result.emailConfirmationRequired) {
        setSuccess(
          'Conta criada. Confirme o e-mail enviado para você e depois entre no Conecta+.',
        );
      } else {
        router.replace('/(tabs)/discover');
      }
    } catch (cause) {
      setError(getFriendlyError(cause));
    } finally {
      setBusy(false);
    }
  };

  return (
    <PageContainer style={{ backgroundColor: colors.background }}>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[
          styles.content,
          { paddingTop: 24, paddingBottom: insets.bottom + 28 },
        ]}
        bottomOffset={28}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <BrandMark compact />
        <View style={styles.intro}>
          <Text style={[styles.title, { color: colors.foreground }]}>Crie sua conta</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            Um espaço para conhecer gente nova e conversar de verdade.
          </Text>
        </View>

        {!supabaseReady ? (
          <InlineNotice
            tone="warning"
            title="Supabase ainda não conectado"
            body="Adicione a URL e a chave pública do projeto para ativar o cadastro."
          />
        ) : null}
        {Platform.OS === 'web' ? (
          <InlineNotice
            tone="warning"
            title="Abra o Conecta+ no Expo Go"
            body="Esta é a prévia Web. O link de confirmação voltaria ao navegador, não ao app Android."
          />
        ) : null}
        {error ? <InlineNotice tone="warning" title="Revise seus dados" body={error} /> : null}
        {success ? (
          <InlineNotice tone="success" title="Cadastro iniciado" body={success} />
        ) : null}

        <View style={styles.form}>
          <Field
            label="Seu nome"
            icon="user"
            value={displayName}
            onChangeText={setDisplayName}
            placeholder="Como você quer ser chamado?"
            autoCapitalize="words"
            autoComplete="name"
            textContentType="name"
            maxLength={80}
            testID="register-name"
          />
          <Field
            label="Nome de usuário"
            icon="at-sign"
            value={username}
            onChangeText={(value) =>
              setUsername(value.toLowerCase().replace(/[^a-z0-9_]/g, ''))
            }
            placeholder="seunome"
            autoCapitalize="none"
            maxLength={24}
            autoComplete="username"
            textContentType="username"
            testID="register-username"
          />
          <Field
            label="E-mail"
            icon="mail"
            value={email}
            onChangeText={setEmail}
            placeholder="voce@exemplo.com"
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
            textContentType="emailAddress"
            testID="register-email"
          />
          <Field
            label="Senha"
            icon="lock"
            value={password}
            onChangeText={setPassword}
            placeholder="Mínimo de 8 caracteres"
            secureTextEntry
            autoCapitalize="none"
            autoComplete="new-password"
            textContentType="newPassword"
            testID="register-password"
          />
          <Field
            label="Confirme a senha"
            icon="check"
            value={confirmation}
            onChangeText={setConfirmation}
            placeholder="Digite a senha novamente"
            secureTextEntry
            autoCapitalize="none"
            autoComplete="new-password"
            textContentType="newPassword"
            onSubmitEditing={() => void handleRegister()}
            testID="register-confirm-password"
          />
          <PrimaryButton
            title="Criar conta"
            icon="user-plus"
            onPress={() => void handleRegister()}
            loading={busy}
            testID="register-submit"
          />
        </View>

        <View style={styles.loginRow}>
          <Text style={[styles.loginText, { color: colors.mutedForeground }]}>
            Já tem uma conta?
          </Text>
          <Link href="/(auth)/login" asChild>
            <Pressable accessibilityRole="button">
              <Text style={[styles.loginLink, { color: colors.primary }]}>Entrar</Text>
            </Pressable>
          </Link>
        </View>
      </KeyboardAwareScrollViewCompat>
    </PageContainer>
  );
}

const styles = StyleSheet.create({
  content: { flexGrow: 1, paddingHorizontal: 24, gap: 20 },
  intro: { gap: 7, marginTop: 6 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 28, letterSpacing: -0.7 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21 },
  form: { gap: 14 },
  loginRow: { flexDirection: 'row', justifyContent: 'center', gap: 5, paddingTop: 3 },
  loginText: { fontFamily: 'Inter_400Regular', fontSize: 13 },
  loginLink: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
});
