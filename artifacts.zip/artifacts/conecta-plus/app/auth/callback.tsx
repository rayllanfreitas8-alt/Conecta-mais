import { useEffect, useRef, useState } from 'react';
import { router, useLocalSearchParams } from 'expo-router';
import type { EmailOtpType } from '@supabase/supabase-js';
import { ActivityIndicator, Platform, StyleSheet, Text, View } from 'react-native';
import { PageContainer, PrimaryButton } from '@/components/ConectaUI';
import { supabase } from '@/lib/supabase';
import { useColors } from '@/hooks/useColors';

type CallbackParams = {
  code?: string | string[];
  token_hash?: string | string[];
  type?: string | string[];
  access_token?: string | string[];
  refresh_token?: string | string[];
  error?: string | string[];
  error_code?: string | string[];
  error_description?: string | string[];
};

const emailOtpTypes = new Set<EmailOtpType>([
  'signup',
  'invite',
  'magiclink',
  'recovery',
  'email_change',
  'email',
]);

function firstParam(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value;
}

function getCallbackErrorCategory(error: unknown) {
  const rawMessage =
    error instanceof Error
      ? error.message
      : typeof error === 'string'
        ? error
        : '';

  if (/code verifier/i.test(rawMessage)) {
    return 'missing_pkce_verifier';
  }

  if (/expired|otp_expired|already used|invalid.*code/i.test(rawMessage)) {
    return 'expired_or_used_link';
  }

  return 'auth_exchange_failed';
}

function getCallbackErrorMessage(category: string) {
  if (category === 'missing_pkce_verifier') {
    return 'Este link precisa ser aberto na mesma instalação do Conecta+ que iniciou o cadastro. Tente no mesmo celular e no mesmo Expo Go. Se o e-mail já foi confirmado, entre com seu e-mail e senha.';
  }

  if (category === 'expired_or_used_link') {
    return 'Este link expirou ou já foi usado. Volte ao Conecta+ e entre; se o e-mail ainda não estiver confirmado, solicite um novo link.';
  }

  return 'Não foi possível confirmar este e-mail. Volte ao Conecta+ e entre; se necessário, solicite um novo link de confirmação.';
}

export default function AuthCallbackScreen() {
  const colors = useColors();
  const {
    code: rawCode,
    token_hash: rawTokenHash,
    type: rawType,
    access_token: rawAccessToken,
    refresh_token: rawRefreshToken,
    error: rawError,
    error_code: rawErrorCode,
    error_description: rawErrorDescription,
  } = useLocalSearchParams<CallbackParams>();
  const code = firstParam(rawCode);
  const tokenHash = firstParam(rawTokenHash);
  const otpType = firstParam(rawType);
  const accessToken = firstParam(rawAccessToken);
  const refreshToken = firstParam(rawRefreshToken);
  const callbackError = firstParam(rawError);
  const callbackErrorCode = firstParam(rawErrorCode);
  const callbackErrorDescription = firstParam(rawErrorDescription);
  const attemptedCallback = useRef<string | null>(null);
  const [status, setStatus] = useState<'processing' | 'error'>('processing');
  const [message, setMessage] = useState('Confirmando seu e-mail…');

  useEffect(() => {
    const callbackKey =
      code ??
      (tokenHash && otpType ? `${tokenHash}:${otpType}` : null) ??
      (accessToken && refreshToken ? 'session-callback' : null);
    const hasCallbackError = Boolean(
      callbackError || callbackErrorCode || callbackErrorDescription,
    );

    if (__DEV__) {
      console.info('[Conecta+] Callback recebido:', {
        platform: Platform.OS,
        hasCode: Boolean(code),
        hasTokenHash: Boolean(tokenHash),
        hasSessionTokens: Boolean(accessToken && refreshToken),
        hasAuthError: hasCallbackError,
      });
    }

    if (!callbackKey) {
      if (__DEV__) {
        console.warn('[Conecta+] Callback sem credencial de confirmação:', {
          platform: Platform.OS,
          category: hasCallbackError ? 'supabase_rejected_link' : 'missing_callback_params',
        });
      }
      setStatus('error');
      setMessage(
        hasCallbackError
          ? 'O Supabase não conseguiu validar este link. Volte ao Conecta+ e tente entrar; se necessário, peça um novo e-mail de confirmação.'
          : 'Este link não trouxe os dados de confirmação. Volte ao Conecta+ e tente entrar; se necessário, peça um novo e-mail de confirmação.',
      );
      return;
    }

    // Avoid exchanging a one-time PKCE code twice during development remounts.
    if (attemptedCallback.current === callbackKey) return;
    attemptedCallback.current = callbackKey;

    const finish = async () => {
      if (!supabase) {
        if (__DEV__) {
          console.warn('[Conecta+] Callback sem cliente Supabase configurado.');
        }
        setStatus('error');
        setMessage('O Conecta+ não conseguiu se conectar ao Supabase. Tente novamente mais tarde.');
        return;
      }

      try {
        if (hasCallbackError) {
          throw new Error(
            callbackErrorDescription ||
              callbackErrorCode ||
              callbackError ||
              'Não foi possível validar o link.',
          );
        }

        let hasAuthSession = false;
        if (code) {
          const { data, error } = await supabase.auth.exchangeCodeForSession(code);
          if (error) throw error;
          hasAuthSession = Boolean(data.session);
        } else if (tokenHash && otpType && emailOtpTypes.has(otpType as EmailOtpType)) {
          const { data, error } = await supabase.auth.verifyOtp({
            token_hash: tokenHash,
            type: otpType as EmailOtpType,
          });
          if (error) throw error;
          hasAuthSession = Boolean(data.session);
        } else if (accessToken && refreshToken) {
          const { data, error } = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken,
          });
          if (error) throw error;
          hasAuthSession = Boolean(data.session);
        } else {
          throw new Error('O formato deste link de confirmação não é compatível.');
        }

        if (!hasAuthSession) {
          throw new Error('confirmation_session_missing');
        }

        const { data: storedSession, error: sessionError } =
          await supabase.auth.getSession();
        if (sessionError) throw sessionError;
        if (!storedSession.session) {
          throw new Error('confirmation_session_not_persisted');
        }

        if (__DEV__) {
          console.info('[Conecta+] Confirmação e sessão processadas:', {
            sessionPersisted: true,
          });
        }
        setMessage('E-mail confirmado. Abrindo o Conecta+…');
        router.replace('/(tabs)/discover');
      } catch (error) {
        const category = getCallbackErrorCategory(error);
        if (__DEV__) {
          console.warn('[Conecta+] Falha no callback:', {
            platform: Platform.OS,
            category,
          });
        }
        setStatus('error');
        setMessage(getCallbackErrorMessage(category));
      }
    };

    void finish();
  }, [
    accessToken,
    callbackError,
    callbackErrorCode,
    callbackErrorDescription,
    code,
    otpType,
    refreshToken,
    tokenHash,
  ]);

  return (
    <PageContainer style={styles.page}>
      <View style={styles.content}>
        {status === 'processing' ? (
          <ActivityIndicator color={colors.primary} size="large" />
        ) : null}
        <Text style={[styles.message, { color: colors.foreground }]}>{message}</Text>
        {status === 'error' ? (
          <PrimaryButton
            title="Voltar ao login"
            onPress={() => router.replace('/(auth)/login')}
          />
        ) : null}
      </View>
    </PageContainer>
  );
}

const styles = StyleSheet.create({
  page: { justifyContent: 'center' },
  content: { alignItems: 'center', gap: 18, paddingHorizontal: 28, width: '100%' },
  message: { fontFamily: 'Inter_500Medium', fontSize: 15, lineHeight: 23, textAlign: 'center' },
});
