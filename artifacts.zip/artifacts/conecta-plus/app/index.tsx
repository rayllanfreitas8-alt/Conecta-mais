import { Redirect } from 'expo-router';
import { LoadingState, PageContainer } from '@/components/ConectaUI';
import { useAuth } from '@/context/AuthContext';

export default function IndexScreen() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <PageContainer style={{ justifyContent: 'center' }}>
        <LoadingState label="Preparando seu espaço…" />
      </PageContainer>
    );
  }

  return user ? (
    <Redirect href="/(tabs)/discover" />
  ) : (
    <Redirect href="/(auth)/login" />
  );
}
