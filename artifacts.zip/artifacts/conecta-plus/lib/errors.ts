export function getFriendlyError(error: unknown) {
  const message =
    error instanceof Error
      ? error.message
      : typeof error === 'string'
        ? error
        : 'Ocorreu um erro inesperado.';

  if (/invalid login credentials/i.test(message)) {
    return 'E-mail ou senha incorretos.';
  }
  if (/email not confirmed/i.test(message)) {
    return 'Confirme seu e-mail antes de entrar.';
  }
  if (/duplicate key|unique constraint|already exists/i.test(message)) {
    return 'Esse nome de usuário já está em uso.';
  }
  if (/relation .* does not exist|schema cache/i.test(message)) {
    return 'As tabelas ainda não foram criadas. Execute o arquivo supabase/schema.sql no SQL Editor do Supabase.';
  }
  if (/row-level security|permission denied|not allowed/i.test(message)) {
    return 'O Supabase bloqueou esta ação pelas regras de segurança. Confira as políticas do banco.';
  }

  return message;
}
