import { requireSupabase } from '@/lib/supabase';
import type { Profile } from '@/context/AuthContext';

export type SocialProfile = Pick<
  Profile,
  'id' | 'display_name' | 'username' | 'bio' | 'city' | 'avatar_url'
>;

export type FriendRequest = {
  id: string;
  sender_id: string;
  recipient_id: string;
  status: 'pending' | 'accepted' | 'declined';
  person: SocialProfile;
};

export type FriendOverview = {
  incoming: FriendRequest[];
  friends: SocialProfile[];
  pendingSentIds: string[];
};

export type ConversationPreview = {
  conversation_id: string;
  other_user_id: string;
  other_display_name: string;
  other_username: string;
  other_avatar_url: string | null;
  last_message: string | null;
  last_message_at: string | null;
};

export type Message = {
  id: string;
  conversation_id: string;
  sender_id: string;
  body: string;
  created_at: string;
};

async function fetchProfiles(ids: string[]) {
  if (ids.length === 0) return new Map<string, SocialProfile>();

  const { data, error } = await requireSupabase()
    .from('profiles')
    .select('id, display_name, username, bio, city, avatar_url')
    .in('id', ids);

  if (error) throw error;
  return new Map(
    ((data ?? []) as SocialProfile[]).map((profile) => [profile.id, profile]),
  );
}

export async function fetchDiscoverProfiles(userId: string) {
  const client = requireSupabase();
  const [{ data: profiles, error: profileError }, { data: requests, error: requestError }] =
    await Promise.all([
      client
        .from('profiles')
        .select('id, display_name, username, bio, city, avatar_url')
        .neq('id', userId)
        .eq('is_discoverable', true)
        .order('created_at', { ascending: false })
        .limit(100),
      client
        .from('friend_requests')
        .select('sender_id, recipient_id, status')
        .or(`sender_id.eq.${userId},recipient_id.eq.${userId}`),
    ]);

  if (profileError) throw profileError;
  if (requestError) throw requestError;

  const connectedIds = new Set<string>();
  for (const request of requests ?? []) {
    if (request.status === 'accepted' || request.status === 'pending') {
      connectedIds.add(
        request.sender_id === userId ? request.recipient_id : request.sender_id,
      );
    }
  }

  return ((profiles ?? []) as SocialProfile[]).filter(
    (profile) => !connectedIds.has(profile.id),
  );
}

export async function fetchFriendOverview(userId: string): Promise<FriendOverview> {
  const { data, error } = await requireSupabase()
    .from('friend_requests')
    .select('id, sender_id, recipient_id, status')
    .or(`sender_id.eq.${userId},recipient_id.eq.${userId}`)
    .order('created_at', { ascending: false });

  if (error) throw error;
  const rows = (data ?? []) as Omit<FriendRequest, 'person'>[];
  const otherIds = [
    ...new Set(
      rows
        .filter((row) => row.status === 'pending' || row.status === 'accepted')
        .map((row) => (row.sender_id === userId ? row.recipient_id : row.sender_id)),
    ),
  ];
  const profiles = await fetchProfiles(otherIds);

  const incoming = rows
    .filter(
      (row) => row.status === 'pending' && row.recipient_id === userId,
    )
    .flatMap((row) => {
      const person = profiles.get(row.sender_id);
      return person ? [{ ...row, person } as FriendRequest] : [];
    });

  const friendsById = new Map<string, SocialProfile>();
  for (const row of rows) {
    if (row.status !== 'accepted') continue;
    const otherId = row.sender_id === userId ? row.recipient_id : row.sender_id;
    const person = profiles.get(otherId);
    if (person) friendsById.set(person.id, person);
  }

  return {
    incoming,
    friends: [...friendsById.values()],
    pendingSentIds: rows
      .filter((row) => row.status === 'pending' && row.sender_id === userId)
      .map((row) => row.recipient_id),
  };
}

export async function sendFriendRequest(recipientId: string) {
  const { error } = await requireSupabase().rpc('send_friend_request', {
    p_recipient_id: recipientId,
  });
  if (error) throw error;
}

export async function respondToFriendRequest(
  requestId: string,
  response: 'accepted' | 'declined',
) {
  const { error } = await requireSupabase().rpc('respond_to_friend_request', {
    p_request_id: requestId,
    p_response: response,
  });
  if (error) throw error;
}

export async function startDirectConversation(otherUserId: string) {
  const { data, error } = await requireSupabase().rpc(
    'start_direct_conversation',
    { p_other_user_id: otherUserId },
  );
  if (error) throw error;
  return data as string;
}

export async function fetchConversations() {
  const { data, error } = await requireSupabase().rpc('list_my_conversations');
  if (error) throw error;
  return (data ?? []) as ConversationPreview[];
}

export async function fetchMessages(conversationId: string) {
  const { data, error } = await requireSupabase()
    .from('messages')
    .select('id, conversation_id, sender_id, body, created_at')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: false })
    .limit(100);

  if (error) throw error;
  return (data ?? []) as Message[];
}

export async function sendMessage(
  conversationId: string,
  senderId: string,
  body: string,
) {
  const cleanBody = body.trim();
  if (!cleanBody || cleanBody.length > 3000) {
    throw new Error('A mensagem deve ter entre 1 e 3.000 caracteres.');
  }

  const { error } = await requireSupabase().from('messages').insert({
    conversation_id: conversationId,
    sender_id: senderId,
    body: cleanBody,
  });

  if (error) throw error;
}
