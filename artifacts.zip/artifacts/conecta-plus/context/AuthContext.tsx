import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { AppState, Platform } from 'react-native';
import type { Session, User } from '@supabase/supabase-js';
import * as Linking from 'expo-linking';
import { getFriendlyError } from '@/lib/errors';
import { supabase, supabaseConfigured } from '@/lib/supabase';

export type Profile = {
  id: string;
  display_name: string;
  username: string;
  bio: string | null;
  city: string | null;
  avatar_url: string | null;
  is_discoverable: boolean;
  updated_at: string;
};

export type ProfileChanges = Partial<
  Pick<
    Profile,
    | 'display_name'
    | 'username'
    | 'bio'
    | 'city'
    | 'avatar_url'
    | 'is_discoverable'
  >
>;

type AuthContextValue = {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  supabaseReady: boolean;
  profileError: string | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (
    email: string,
    password: string,
    displayName: string,
    username: string,
  ) => Promise<{ emailConfirmationRequired: boolean }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<Profile | null>;
  saveProfile: (changes: ProfileChanges) => Promise<Profile>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

function getEmailConfirmationRedirect() {
  if (Platform.OS === 'web') {
    throw new Error(
      'Para confirmar o e-mail e voltar ao Conecta+ Android, inicie o cadastro pelo app aberto no Expo Go. A prévia Web usa outro endereço de retorno.',
    );
  }

  // Keep the path relative: Expo Go supplies its current exp:// host, while a
  // standalone Android build resolves the app.json scheme.
  const redirectTo = Linking.createURL('auth/callback');

  let parsedRedirect: URL;
  try {
    parsedRedirect = new URL(redirectTo);
  } catch {
    throw new Error(
      'Não foi possível preparar o retorno do e-mail. Abra o Conecta+ pelo Expo Go usando o QR atual e tente novamente.',
    );
  }

  if (
    ['localhost', '127.0.0.1', '0.0.0.0', '::1'].includes(
      parsedRedirect.hostname.toLowerCase(),
    )
  ) {
    throw new Error(
      'O retorno do e-mail apontaria para localhost. Abra o Conecta+ no Expo Go pelo QR atual e crie a conta novamente.',
    );
  }

  if (!['exp:', 'conecta-plus:'].includes(parsedRedirect.protocol.toLowerCase())) {
    throw new Error(
      'O retorno do e-mail não está usando um link do app. Abra o Conecta+ pelo Expo Go no celular e tente novamente.',
    );
  }

  if (__DEV__) {
    console.info('[Conecta+] Retorno de confirmação preparado:', {
      platform: Platform.OS,
      scheme: parsedRedirect.protocol.replace(':', ''),
      target:
        parsedRedirect.protocol === 'exp:'
          ? 'Expo Go'
          : parsedRedirect.protocol === 'conecta-plus:'
            ? 'app instalado'
            : 'Web',
      route: 'auth/callback',
    });
  }

  return redirectTo;
}

async function readProfile(userId: string) {
  if (!supabase) return null;

  const { data, error } = await supabase
    .from('profiles')
    .select(
      'id, display_name, username, bio, city, avatar_url, is_discoverable, updated_at',
    )
    .eq('id', userId)
    .maybeSingle();

  if (error) throw error;
  return (data as Profile | null) ?? null;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [profileError, setProfileError] = useState<string | null>(null);

  const refreshProfile = useCallback(async () => {
    if (!supabase || !user) {
      setProfile(null);
      return null;
    }

    try {
      const nextProfile = await readProfile(user.id);
      setProfile(nextProfile);
      setProfileError(null);
      return nextProfile;
    } catch (error) {
      setProfileError(getFriendlyError(error));
      throw error;
    }
  }, [user]);

  useEffect(() => {
    if (!supabase) {
      setLoading(false);
      return;
    }
    const client = supabase;

    let mounted = true;
    let profileLoad = 0;

    const loadForSession = async (session: Session | null) => {
      const nextUser = session?.user ?? null;
      setUser(nextUser);

      if (!nextUser) {
        profileLoad += 1;
        setProfile(null);
        setProfileError(null);
        setLoading(false);
        return;
      }

      const currentLoad = ++profileLoad;
      setLoading(true);
      try {
        const nextProfile = await readProfile(nextUser.id);
        if (mounted && currentLoad === profileLoad) {
          setProfile(nextProfile);
          setProfileError(null);
        }
      } catch (error) {
        if (mounted && currentLoad === profileLoad) {
          setProfileError(getFriendlyError(error));
        }
      } finally {
        if (mounted && currentLoad === profileLoad) setLoading(false);
      }
    };

    const { data } = client.auth.onAuthStateChange((_event, session) => {
      // Defer database work outside the auth event callback.
      setTimeout(() => {
        if (mounted) void loadForSession(session);
      }, 0);
    });
    client.auth.startAutoRefresh();

    void client.auth
      .getSession()
      .then(({ data: sessionData, error }) => {
        if (error) throw error;
        if (mounted) return loadForSession(sessionData.session);
        return undefined;
      })
      .catch((error: unknown) => {
        if (mounted) {
          setProfileError(getFriendlyError(error));
          setLoading(false);
        }
      });

    const appStateSubscription = AppState.addEventListener(
      'change',
      (state) => {
        if (state === 'active') client.auth.startAutoRefresh();
        else client.auth.stopAutoRefresh();
      },
    );

    return () => {
      mounted = false;
      data.subscription.unsubscribe();
      appStateSubscription.remove();
      client.auth.stopAutoRefresh();
    };
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    if (!supabase) {
      throw new Error(
        'O Supabase ainda não foi configurado. Adicione a URL e a chave pública do projeto para continuar.',
      );
    }

    const { error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    if (error) throw error;
  }, []);

  const signUp = useCallback(
    async (
      email: string,
      password: string,
      displayName: string,
      username: string,
    ) => {
      if (!supabase) {
        throw new Error(
          'O Supabase ainda não foi configurado. Adicione a URL e a chave pública do projeto para continuar.',
        );
      }

      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          emailRedirectTo: getEmailConfirmationRedirect(),
          data: {
            display_name: displayName.trim(),
            username: username.trim().toLowerCase(),
          },
        },
      });
      if (error) throw error;

      return { emailConfirmationRequired: !data.session };
    },
    [],
  );

  const signOut = useCallback(async () => {
    if (!supabase) return;
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  }, []);

  const saveProfile = useCallback(
    async (changes: ProfileChanges) => {
      if (!supabase || !user) {
        throw new Error('Entre na sua conta para atualizar o perfil.');
      }

      if (
        changes.username !== undefined &&
        !/^[a-z0-9_]{3,24}$/.test(changes.username)
      ) {
        throw new Error(
          'O nome de usuário deve ter de 3 a 24 caracteres: letras, números ou sublinhado.',
        );
      }

      const { data, error } = await supabase
        .from('profiles')
        .update({ ...changes, updated_at: new Date().toISOString() })
        .eq('id', user.id)
        .select(
          'id, display_name, username, bio, city, avatar_url, is_discoverable, updated_at',
        )
        .single();

      if (error) throw error;
      const updatedProfile = data as Profile;
      setProfile(updatedProfile);
      setProfileError(null);
      return updatedProfile;
    },
    [user],
  );

  const value = useMemo(
    () => ({
      user,
      profile,
      loading,
      supabaseReady: supabaseConfigured,
      profileError,
      signIn,
      signUp,
      signOut,
      refreshProfile,
      saveProfile,
    }),
    [
      user,
      profile,
      loading,
      profileError,
      signIn,
      signUp,
      signOut,
      refreshProfile,
      saveProfile,
    ],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de AuthProvider.');
  }
  return context;
}
