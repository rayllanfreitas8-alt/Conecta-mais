import { Feather } from '@expo/vector-icons';
import { Image, Platform, Pressable, StyleSheet, Text, TextInput, View, type TextInputProps, type ViewStyle } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type FeatherName = React.ComponentProps<typeof Feather>['name'];

export function PageContainer({
  children,
  style,
}: {
  children: React.ReactNode;
  style?: ViewStyle;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[
        styles.page,
        {
          backgroundColor: colors.background,
          paddingTop: Platform.OS === 'web' ? Math.max(insets.top, 67) : 0,
        },
        style,
      ]}
    >
      {children}
    </SafeAreaView>
  );
}

export function BrandMark({ compact = false }: { compact?: boolean }) {
  const colors = useColors();
  return (
    <View style={styles.brandRow}>
      <Image
        accessibilityLabel="Símbolo do Conecta+"
        source={require('../assets/images/icon.png')}
        style={[styles.brandImage, compact && styles.brandImageCompact]}
      />
      <View>
        <Text style={[styles.brandName, { color: colors.foreground }]}>
          Conecta<Text style={{ color: colors.primary }}>+</Text>
        </Text>
        {!compact && (
          <Text style={[styles.brandCaption, { color: colors.mutedForeground }]}>
            Conexões que aproximam
          </Text>
        )}
      </View>
    </View>
  );
}

export function ScreenHeading({
  title,
  subtitle,
  eyebrow,
  right,
}: {
  title: string;
  subtitle?: string;
  eyebrow?: string;
  right?: React.ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.headingRow}>
      <View style={styles.headingText}>
        {eyebrow ? (
          <Text style={[styles.eyebrow, { color: colors.primary }]}>{eyebrow}</Text>
        ) : null}
        <Text style={[styles.heading, { color: colors.foreground }]}>{title}</Text>
        {subtitle ? (
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      {right}
    </View>
  );
}

export function Field({
  label,
  icon,
  style,
  ...props
}: TextInputProps & { label: string; icon?: FeatherName }) {
  const colors = useColors();
  return (
    <View style={styles.fieldWrap}>
      <Text style={[styles.fieldLabel, { color: colors.foreground }]}>{label}</Text>
      <View
        style={[
          styles.fieldBox,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
          },
        ]}
      >
        {icon ? (
          <Feather name={icon} size={17} color={colors.mutedForeground} />
        ) : null}
        <TextInput
          placeholderTextColor={colors.mutedForeground}
          selectionColor={colors.primary}
          style={[styles.fieldInput, { color: colors.foreground }, style]}
          {...props}
        />
      </View>
    </View>
  );
}

export function PrimaryButton({
  title,
  onPress,
  icon,
  disabled,
  loading,
  testID,
}: {
  title: string;
  onPress: () => void;
  icon?: FeatherName;
  disabled?: boolean;
  loading?: boolean;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: !!disabled || !!loading, busy: !!loading }}
      disabled={disabled || loading}
      onPress={onPress}
      testID={testID}
      style={({ pressed }) => [
        styles.primaryButton,
        { backgroundColor: colors.primary },
        (disabled || loading) && styles.disabledButton,
        pressed && !disabled && !loading && styles.pressed,
      ]}
    >
      {icon ? <Feather name={icon} size={17} color={colors.primaryForeground} /> : null}
      <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>
        {loading ? 'Aguarde…' : title}
      </Text>
    </Pressable>
  );
}

export function QuietButton({
  title,
  onPress,
  icon,
  disabled,
  testID,
}: {
  title: string;
  onPress: () => void;
  icon?: FeatherName;
  disabled?: boolean;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: !!disabled }}
      disabled={disabled}
      onPress={onPress}
      testID={testID}
      style={({ pressed }) => [
        styles.quietButton,
        { backgroundColor: colors.secondary },
        pressed && styles.pressed,
        disabled && styles.disabledButton,
      ]}
    >
      {icon ? <Feather name={icon} size={16} color={colors.primary} /> : null}
      <Text style={[styles.quietButtonText, { color: colors.primary }]}>{title}</Text>
    </Pressable>
  );
}

export function InlineNotice({
  title,
  body,
  tone = 'info',
}: {
  title: string;
  body: string;
  tone?: 'info' | 'warning' | 'success';
}) {
  const colors = useColors();
  const toneColor =
    tone === 'warning'
      ? colors.destructive
      : tone === 'success'
        ? colors.primary
        : colors.accentForeground;

  return (
    <View
      style={[
        styles.notice,
        { backgroundColor: colors.secondary, borderColor: colors.border },
      ]}
    >
      <Feather
        name={tone === 'warning' ? 'alert-circle' : tone === 'success' ? 'check-circle' : 'info'}
        size={18}
        color={toneColor}
      />
      <View style={styles.noticeText}>
        <Text style={[styles.noticeTitle, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.noticeBody, { color: colors.mutedForeground }]}>{body}</Text>
      </View>
    </View>
  );
}

export function Avatar({
  name,
  imageUrl,
  size = 48,
}: {
  name: string;
  imageUrl?: string | null;
  size?: number;
}) {
  const colors = useColors();
  const initials =
    name
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part[0]?.toLocaleUpperCase('pt-BR') ?? '')
      .join('') || 'C';

  return (
    <View
      style={[
        styles.avatar,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: colors.secondary,
        },
      ]}
    >
      {imageUrl ? (
        <Image
          accessibilityLabel={`Foto de ${name}`}
          source={{ uri: imageUrl }}
          style={{
            width: size,
            height: size,
            borderRadius: size / 2,
          }}
        />
      ) : (
        <Text style={[styles.avatarText, { color: colors.primary, fontSize: size * 0.33 }]}>
          {initials}
        </Text>
      )}
    </View>
  );
}

export function EmptyState({
  title,
  body,
  icon = 'users',
  action,
}: {
  title: string;
  body: string;
  icon?: FeatherName;
  action?: React.ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={[styles.emptyState, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
        <Feather name={icon} size={22} color={colors.primary} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>{body}</Text>
      {action}
    </View>
  );
}

export function LoadingState({ label = 'Carregando…' }: { label?: string }) {
  const colors = useColors();
  return (
    <View style={styles.loadingState}>
      <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}

export function IconButton({
  icon,
  onPress,
  label,
  testID,
}: {
  icon: FeatherName;
  onPress: () => void;
  label: string;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      testID={testID}
      hitSlop={10}
      style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}
    >
      <Feather name={icon} size={20} color={colors.foreground} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  brandImage: { width: 48, height: 48, borderRadius: 14 },
  brandImageCompact: { width: 34, height: 34, borderRadius: 10 },
  brandName: { fontFamily: 'Inter_700Bold', fontSize: 23, letterSpacing: -0.8 },
  brandCaption: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 1 },
  headingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  headingText: { flex: 1 },
  eyebrow: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 11,
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 7,
  },
  heading: { fontFamily: 'Inter_700Bold', fontSize: 27, letterSpacing: -0.8 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21, marginTop: 5 },
  fieldWrap: { gap: 8 },
  fieldLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  fieldBox: {
    minHeight: 52,
    borderWidth: 1,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 15,
  },
  fieldInput: {
    flex: 1,
    minHeight: 48,
    paddingVertical: 10,
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
  },
  primaryButton: {
    minHeight: 52,
    borderRadius: 16,
    paddingHorizontal: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 9,
  },
  primaryButtonText: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  quietButton: {
    minHeight: 42,
    borderRadius: 14,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
  },
  quietButtonText: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  disabledButton: { opacity: 0.55 },
  pressed: { opacity: 0.78 },
  notice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 11,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
  },
  noticeText: { flex: 1, gap: 3 },
  noticeTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  noticeBody: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18 },
  avatar: { alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  avatarText: { fontFamily: 'Inter_700Bold' },
  emptyState: {
    alignItems: 'center',
    paddingHorizontal: 22,
    paddingVertical: 26,
    borderWidth: 1,
    borderRadius: 22,
    gap: 10,
  },
  emptyIcon: { width: 48, height: 48, alignItems: 'center', justifyContent: 'center', borderRadius: 16, marginBottom: 3 },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 16, textAlign: 'center' },
  emptyBody: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 19, textAlign: 'center' },
  loadingState: { minHeight: 90, alignItems: 'center', justifyContent: 'center' },
  loadingText: { fontFamily: 'Inter_500Medium', fontSize: 14 },
  iconButton: { width: 42, height: 42, alignItems: 'center', justifyContent: 'center' },
});
