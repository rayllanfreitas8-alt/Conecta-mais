/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#28243A',
    tint: '#7049F6',

    // Core surfaces
    background: '#F7F5FB',
    foreground: '#28243A',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#28243A',

    // Primary action color (buttons, links, active states)
    primary: '#7049F6',
    primaryForeground: '#FFFFFF',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#EFEAFF',
    secondaryForeground: '#42366F',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#F0EEF5',
    mutedForeground: '#7D778F',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#FBE9E7',
    accentForeground: '#9B514D',

    // Destructive actions (delete, error states)
    destructive: '#D84F68',
    destructiveForeground: '#FFFFFF',

    // Borders and input outlines
    border: '#E7E2EF',
    input: '#E7E2EF',
  },
  dark: {
    text: '#F6F2FF',
    tint: '#B7A0FF',
    background: '#171420',
    foreground: '#F6F2FF',
    card: '#211D2C',
    cardForeground: '#F6F2FF',
    primary: '#A38AFF',
    primaryForeground: '#20183A',
    secondary: '#302941',
    secondaryForeground: '#E7DEFF',
    muted: '#2A2635',
    mutedForeground: '#AAA2B7',
    accent: '#463038',
    accentForeground: '#FFB9B1',
    destructive: '#FF7388',
    destructiveForeground: '#2D1119',
    border: '#393345',
    input: '#393345',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 18,
};

export default colors;
