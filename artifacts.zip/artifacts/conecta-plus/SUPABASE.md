# Configurar o Supabase do Conecta+

O app está preparado para usar Supabase Auth, PostgreSQL, regras RLS e Realtime. A autenticação e as consultas ficam inativas até você ligar um projeto Supabase.

## 1. Criar um projeto Supabase

Crie um projeto no painel do Supabase. Em **Connect**, copie a **Project URL** e a **Publishable key** (chave pública `sb_publishable_…`).

## 2. Adicionar a configuração ao app

No ambiente do app no Replit, configure a URL e a chave pública:

- `EXPO_PUBLIC_SUPABASE_URL` — a Project URL (variável de ambiente).
- `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` — a Publishable key (`sb_publishable_…`), preferida.
- `EXPO_PUBLIC_SUPABASE_ANON_KEY` — alternativa compatível com a chave pública anon antiga; use-a no lugar da Publishable key se foi essa que o painel forneceu.

O app aceita os dois nomes de chave, priorizando `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` se ambos estiverem definidos. A `ANON_KEY` também é uma chave pública de cliente. Essas informações são próprias para uso no app. **Nunca** coloque `service_role`, uma chave secreta do Supabase ou a senha do banco no aplicativo ou no chat; essas credenciais ignoram as regras RLS.

## 3. Criar as tabelas e regras de acesso

No painel do Supabase, abra **SQL Editor**, crie uma consulta e execute o conteúdo de `supabase/schema.sql`. O script agora pode ser reexecutado quando as tabelas existentes tiverem colunas compatíveis. Ele usa transação e não contém `DROP`, `TRUNCATE` ou exclusão de linhas; se detectar uma estrutura incompatível, interrompe a execução.

- perfis e a criação automática do perfil no cadastro;
- solicitações e amizades;
- conversas privadas e mensagens;
- políticas RLS que limitam perfis, solicitações, conversas e mensagens;
- funções de banco para aceitar solicitações e iniciar conversas;
- a publicação de mensagens e solicitações para o Realtime.

O script é aditivo: reutiliza tabelas e índices compatíveis, atualiza as funções RPC do Conecta+ com as mesmas assinaturas e preserva gatilhos ou políticas incompatíveis, interrompendo a execução para revisão. Não remove objetos nem linhas. Antes de executar, faça um backup e confira as mensagens do SQL Editor. Se houver colunas incompatíveis, gatilhos com o mesmo nome mas outra função, dados duplicados que impeçam índices únicos ou políticas com modo incompatível, o script aborta em vez de substituir ou apagar esses objetos. Chaves estrangeiras e validações novas são adicionadas como `NOT VALID` para preservar linhas antigas; elas passam a ser aplicadas a novas gravações.

## 4. Habilitar a confirmação por e-mail

O app envia uma URL de retorno específica no cadastro. A rota canônica do build Android instalado é `auth/callback`; em **Authentication → URL Configuration → Redirect URLs**, permita:

`conecta-plus://auth/callback`

O endereço curto `conecta-plus://callback` também é aceito como alias de compatibilidade, mas a URL canônica acima corresponde diretamente à rota `app/auth/callback`.

No Expo Go, a URL muda conforme a sessão de desenvolvimento. O app registra, sem host, código ou token, se o retorno foi preparado para Expo Go, app instalado ou Web. No celular com Expo Go, o esquema esperado é `exp` e o caminho é `auth/callback`; no build instalado, o esquema esperado é `conecta-plus`. Se o log indicar Web/`https`, o cadastro foi feito na prévia Web, não no Expo Go. Para evitar atualizar a lista quando o endereço do Expo Go mudar, a regra `exp://**/--/auth/callback` pode ser usada apenas para desenvolvimento; mantenha uma URL exata para builds publicados.

Em **Authentication → Providers → Email**, mantenha o provedor de e-mail habilitado. Se a confirmação estiver ativa, abra o e-mail no mesmo aparelho e na mesma instalação do Expo Go usada no cadastro, para que o verificador PKCE esteja disponível. O retorno abre `app/auth/callback`, troca o código PKCE, confirma a persistência da sessão e então abre Descobrir. No log do callback, `hasCode: true` e `sessionPersisted: true` indicam que o código chegou e a sessão foi salva. Falhas registram somente categorias como `missing_pkce_verifier` ou `expired_or_used_link`; os valores dos parâmetros e mensagens brutas não são registrados.

Se o link recebido ainda terminar em `localhost`, confira **Authentication → URL Configuration → Site URL** e o modelo **Authentication → Email Templates → Confirm signup**. A URL de retorno do app não deve estar substituída por `localhost` no modelo. Mantenha o link de confirmação do Supabase (`{{ .ConfirmationURL }}`); não monte o link final a partir de `{{ .SiteURL }}`.

## 5. Reiniciar e conferir

Depois de salvar as variáveis, reinicie a prévia do Conecta+. A tela inicial deve deixar de avisar que o Supabase não está conectado. Crie duas contas de teste em dispositivos/sessões diferentes para verificar solicitações e mensagens ao vivo.

O app não inclui pagamentos, cobranças, Pix ou armazenamento de cartões.
